"""Reviewer-1 comments 2, 3 and 9.

C2: RF complexity - hyperparameter sensitivity on the test block, selection by ROI-grouped CV on the
    training blocks and by the validation block, OOB score, learning curve over L2 training ROIs.
C3: independence - ROI-level effective sample size (axis ICC), block-boundary buffer exclusion,
    spatial semivariogram of ROI porosity / L1 log-permeability, residual autocorrelation.
C9: uncertainty for the principal RF result - case vs ROI-clustered bootstrap, ROI sign-flip
    permutation test, split-conformal prediction intervals calibrated on the validation block.
"""
from __future__ import annotations

import itertools
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import GroupKFold

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "results" / "operator_v1"
OUT = BASE / "revision_r1" / "complexity_independence_uncertainty"
OUT.mkdir(parents=True, exist_ok=True)
FULL = ["log10_l1_k", "porosity", "largest_component_fraction_of_pore", "log10_connected_components_6", "axis_x", "axis_y", "axis_z"]
VOX_UM = 4.95
REPORT: dict = {}


def r2(y, p):
    return float(1 - np.sum((y - p) ** 2) / np.sum((y - np.mean(y)) ** 2))


def rmse(y, p):
    return float(np.sqrt(np.mean((y - p) ** 2)))


def rf(seed=1701, n=500, leaf=2, depth=None, mf=1.0, oob=False):
    return RandomForestRegressor(n_estimators=n, min_samples_leaf=leaf, max_depth=depth, max_features=mf,
                                 random_state=seed, n_jobs=-1, oob_score=oob)


def load():
    t = pd.read_csv(BASE / "multifidelity_correction" / "multifidelity_training_table.csv")
    return t[t.split == "train"].reset_index(drop=True), t[t.split == "validation"].reset_index(drop=True), t[t.split == "test"].reset_index(drop=True)


# ----------------------------------------------------------------- C2
def comment2(train, val, test):
    X, y, g = train[FULL], train.log10_l2_k.to_numpy(), train.roi_id.to_numpy()
    yt, yv = test.log10_l2_k.to_numpy(), val.log10_l2_k.to_numpy()
    rows = []
    gkf = GroupKFold(n_splits=6)
    grid = list(itertools.product([1, 2, 3, 5, 8], [None, 3, 5, 8], [1.0, 0.6, 0.33]))
    for leaf, depth, mf in grid:
        cv = []
        for tr, va in gkf.split(X, y, g):
            m = rf(n=150, leaf=leaf, depth=depth, mf=mf).fit(X.iloc[tr], y[tr])
            cv.append(rmse(y[va], m.predict(X.iloc[va])))
        m = rf(n=300, leaf=leaf, depth=depth, mf=mf).fit(X, y)
        rows.append({"min_samples_leaf": leaf, "max_depth": "None" if depth is None else depth, "max_features": mf,
                     "grouped_cv_rmse_train": float(np.mean(cv)),
                     "validation_r2": r2(yv, m.predict(val[FULL])), "validation_rmse": rmse(yv, m.predict(val[FULL])),
                     "test_r2": r2(yt, m.predict(test[FULL])), "test_rmse": rmse(yt, m.predict(test[FULL]))})
    grid_df = pd.DataFrame(rows)
    grid_df.to_csv(OUT / "c2_rf_hyperparameter_grid.csv", index=False)
    by_cv = grid_df.loc[grid_df.grouped_cv_rmse_train.idxmin()]
    by_val = grid_df.loc[grid_df.validation_rmse.idxmin()]
    trees = []
    for n in (100, 300, 500, 1000):
        r = [r2(yt, rf(seed=s, n=n).fit(X, y).predict(test[FULL])) for s in range(1701, 1706)]
        trees.append({"n_estimators": n, "test_r2_mean": float(np.mean(r)), "test_r2_sd": float(np.std(r))})
    pd.DataFrame(trees).to_csv(OUT / "c2_n_estimators.csv", index=False)
    oob = rf(oob=True).fit(X, y)
    # learning curve over number of training ROIs
    rois = np.unique(g); rng = np.random.default_rng(1701); lc = []
    for k in (6, 12, 18, 24):
        for rep in range(20 if k < 24 else 1):
            pick = rng.choice(rois, k, replace=False) if k < 24 else rois
            sub = train[train.roi_id.isin(pick)]
            p_rf = rf(n=300, seed=1701 + rep).fit(sub[FULL], sub.log10_l2_k).predict(test[FULL])
            p_lin = LinearRegression().fit(sub[["log10_l1_k"]], sub.log10_l2_k).predict(test[["log10_l1_k"]])
            lc.append({"train_rois": k, "train_cases": int(len(sub)), "rep": rep, "rf_test_r2": r2(yt, p_rf), "linear_test_r2": r2(yt, p_lin)})
    lc = pd.DataFrame(lc)
    lc.to_csv(OUT / "c2_learning_curve_raw.csv", index=False)
    lcs = lc.groupby(["train_rois", "train_cases"]).agg(rf_mean=("rf_test_r2", "mean"), rf_sd=("rf_test_r2", "std"),
                                                       linear_mean=("linear_test_r2", "mean"), linear_sd=("linear_test_r2", "std")).reset_index()
    lcs.to_csv(OUT / "c2_learning_curve_summary.csv", index=False)
    REPORT["c2"] = {
        "grid_size": len(grid), "grid": "min_samples_leaf {1,2,3,5,8} x max_depth {None,3,5,8} x max_features {1.0,0.6,0.33}; 300 trees",
        "test_r2_range_over_grid": [float(grid_df.test_r2.min()), float(grid_df.test_r2.max())],
        "test_r2_median_over_grid": float(grid_df.test_r2.median()),
        "selected_by_grouped_cv_on_train": by_cv.to_dict(), "selected_by_validation_block": by_val.to_dict(),
        "oob_r2_main_model": float(oob.oob_score_),
        "n_estimators_sensitivity": trees,
        "learning_curve": lcs.to_dict(orient="records"),
    }


# ----------------------------------------------------------------- C3
def comment3(train, val, test):
    reg = pd.read_csv(BASE / "roi_registry" / "operator_roi_registry_accepted.csv")
    reg = reg[reg.accepted_for_operator.astype(bool)].copy()
    gaps = pd.read_csv(BASE / "revision_r1" / "phase1" / "roi_boundary_gaps.csv")[["roi_id", "gap_to_other_split_voxels"]]
    # (a) ICC of L2 log-k across axes within ROI and effective sample size
    allt = pd.concat([train, val, test])
    icc_rows = []
    for name, col in (("log10_l2_k", "log10_l2_k"), ("log10_l1_k", "log10_l1_k"), ("L2-L1 bias", None)):
        v = allt.log10_l2_k - allt.log10_l1_k if col is None else allt[col]
        d = pd.DataFrame({"roi": allt.roi_id, "v": v.to_numpy()})
        k = 3; grp = d.groupby("roi").v
        msb = k * grp.mean().var(ddof=1); msw = grp.var(ddof=1).mean()
        icc = (msb - msw) / (msb + (k - 1) * msw)
        icc_rows.append({"quantity": name, "icc_within_roi": float(icc), "design_effect": float(1 + (k - 1) * icc),
                         "effective_n_test_cases(36)": float(36 / (1 + (k - 1) * icc))})
    pd.DataFrame(icc_rows).to_csv(OUT / "c3_axis_icc.csv", index=False)
    # (b) buffer exclusion: test ROIs touching the validation block
    tt = test.merge(gaps, on="roi_id", how="left")
    yt = tt.log10_l2_k.to_numpy()
    preds = np.mean([rf(seed=s).fit(train[FULL], train.log10_l2_k).predict(tt[FULL]) for s in range(1701, 1711)], axis=0)
    plin = LinearRegression().fit(train[["log10_l1_k"]], train.log10_l2_k).predict(tt[["log10_l1_k"]])
    buf = []
    for b in (0, 40, 80, 160):
        keep = (tt.gap_to_other_split_voxels > b) if b > 0 else (tt.gap_to_other_split_voxels > 0)
        keep = keep.to_numpy() | np.isnan(tt.gap_to_other_split_voxels.to_numpy())
        k = keep
        buf.append({"exclude_test_rois_within_voxels_of_validation": b if b > 0 else "touching (0)",
                    "test_rois": int(tt[k].roi_id.nunique()), "test_cases": int(k.sum()),
                    "rf_r2": r2(yt[k], preds[k]), "linear_r2": r2(yt[k], plin[k]), "uncorrected_r2": r2(yt[k], tt.log10_l1_k.to_numpy()[k])})
    buf.insert(0, {"exclude_test_rois_within_voxels_of_validation": "none", "test_rois": 12, "test_cases": 36,
                   "rf_r2": r2(yt, preds), "linear_r2": r2(yt, plin), "uncorrected_r2": r2(yt, tt.log10_l1_k.to_numpy())})
    pd.DataFrame(buf).to_csv(OUT / "c3_buffer_exclusion_l2.csv", index=False)
    # same for the larger L1 single-fidelity morphology baseline (45 test ROIs)
    l1 = pd.read_csv(BASE / "operator_dataset" / "operator_l1_4x_cfd_permeability_dataset.csv") if (BASE / "operator_dataset" / "operator_l1_4x_cfd_permeability_dataset.csv").exists() else None
    REPORT["c3_l1_dataset_found"] = l1 is not None
    # (c) semivariogram of ROI porosity and ROI-mean L1 log k (all 180 ROIs, one specimen)
    reg["cz"] = (reg.z_start_global + reg.z_end_global) / 2; reg["cy"] = (reg.y_start + reg.y_end) / 2; reg["cx"] = (reg.x_start + reg.x_end) / 2
    d = pd.read_csv(BASE / "operator_dataset" / "operator_l1_4x_cfd_permeability_dataset.csv")
    l1k = d.groupby("roi_id").log10_permeability_m2.mean(); REPORT["c3_l1_source"] = "operator_l1_4x_cfd_permeability_dataset.csv"
    if l1k is not None:
        reg = reg.merge(l1k.rename("roi_log10_l1_k"), left_on="roi_id", right_index=True, how="left")
    xyz = reg[["cz", "cy", "cx"]].to_numpy(); D = np.sqrt(((xyz[:, None, :] - xyz[None, :, :]) ** 2).sum(-1))
    iu = np.triu_indices(len(reg), 1); dist = D[iu]
    bins = [0, 170, 230, 330, 450, 600, 800, 1100, 1500]
    vg = []
    for col in [c for c in ("porosity", "roi_log10_l1_k") if c in reg]:
        v = reg[col].to_numpy(); sq = 0.5 * (v[:, None] - v[None, :]) ** 2; sq = sq[iu]; sill = float(np.var(v, ddof=1))
        for lo, hi in zip(bins[:-1], bins[1:]):
            m = (dist > lo) & (dist <= hi)
            if m.sum() >= 10:
                vg.append({"variable": col, "lag_lo_vox": lo, "lag_hi_vox": hi, "mean_lag_mm": float(dist[m].mean() * VOX_UM / 1000),
                           "pairs": int(m.sum()), "semivariance": float(sq[m].mean()), "sill_variance": sill,
                           "semivariance_over_sill": float(sq[m].mean() / sill)})
    vg = pd.DataFrame(vg); vg.to_csv(OUT / "c3_semivariogram.csv", index=False)
    # (d) spatial autocorrelation of RF residuals within the test block (Moran's I, inverse-distance, ROI means)
    res = pd.DataFrame({"roi_id": tt.roi_id, "r": yt - preds}).groupby("roi_id").r.mean()
    rr = reg.set_index("roi_id").loc[res.index]
    P = rr[["cz", "cy", "cx"]].to_numpy(); Dm = np.sqrt(((P[:, None] - P[None]) ** 2).sum(-1)); W = np.where(Dm > 0, 1 / np.maximum(Dm, 1), 0)
    z = res.to_numpy() - res.mean(); n = len(z)
    I = float(n / W.sum() * (z @ W @ z) / (z @ z))
    rng = np.random.default_rng(1701); perm = []
    for _ in range(9999):
        zp = rng.permutation(z); perm.append(n / W.sum() * (zp @ W @ zp) / (zp @ zp))
    REPORT["c3"] = {
        "axis_icc": icc_rows, "buffer": buf,
        "train_test_min_separation_voxels": 360, "train_test_min_separation_mm": 360 * VOX_UM / 1000,
        "rf_residual_morans_I_test_rois": I, "morans_I_expected": -1 / (n - 1),
        "morans_I_permutation_p_two_sided": float((np.sum(np.abs(np.array(perm) - np.mean(perm)) >= abs(I - np.mean(perm))) + 1) / 10000),
        "semivariogram": vg.to_dict(orient="records"),
    }


# ----------------------------------------------------------------- C9
def comment9(train, val, test):
    """Uncertainty for the archived Table 7 models (RF and ridge); same ROI bootstrap draws as src/71."""
    ap = pd.read_csv(BASE / "multifidelity_correction" / "multifidelity_correction_predictions.csv")
    yt, l1 = test.log10_l2_k.to_numpy(), test.log10_l1_k.to_numpy()
    rois = test.roi_id.to_numpy(); uniq = np.unique(rois); idx = {r: np.where(rois == r)[0] for r in uniq}
    rng = np.random.default_rng(1701)
    roi_boots = [np.concatenate([idx[r] for r in rng.choice(uniq, len(uniq), replace=True)]) for _ in range(10000)]
    case_boots = [rng.integers(0, len(yt), len(yt)) for _ in range(10000)]
    flips = np.array(list(itertools.product([-1, 1], repeat=len(uniq))))
    out = {}
    for name in ("random_forest", "ridge"):
        a = ap[(ap.model == name) & (ap.split == "test")]
        p = test[["roi_id", "flow_axis"]].merge(a, on=["roi_id", "flow_axis"], how="left", validate="one_to_one").predicted_log10_l2.to_numpy()
        def ci(boots):
            o = np.array([(r2(yt[b], p[b]), rmse(yt[b], p[b]), 100 * (1 - rmse(yt[b], p[b]) / rmse(yt[b], l1[b]))) for b in boots])
            return {k: [float(np.percentile(o[:, i], 2.5)), float(np.percentile(o[:, i], 97.5))] for i, k in enumerate(["r2", "rmse", "rmse_reduction_pct"])}
        d = np.array([np.abs(yt[idx[r]] - l1[idx[r]]).mean() - np.abs(yt[idx[r]] - p[idx[r]]).mean() for r in uniq])
        out[name] = {
            "point": {"r2": r2(yt, p), "rmse": rmse(yt, p), "rmse_reduction_pct": 100 * (1 - rmse(yt, p) / rmse(yt, l1))},
            "case_bootstrap_95ci": ci(case_boots), "roi_clustered_bootstrap_95ci": ci(roi_boots),
            "cases_improved": int((np.abs(yt - p) < np.abs(yt - l1)).sum()),
            "roi_level": {"rois_improved": int((d > 0).sum()), "rois": int(len(d)),
                          "wilcoxon_p_one_sided": float(stats.wilcoxon(d, alternative="greater").pvalue),
                          "sign_flip_permutation_p_one_sided_exact": float(np.mean((flips * d).mean(1) >= d.mean()))},
        }
    m = rf().fit(train[FULL], train.log10_l2_k)
    cal = np.abs(val.log10_l2_k.to_numpy() - m.predict(val[FULL])); pt = m.predict(test[FULL])
    conf = []
    for a_ in (0.10, 0.20):
        q = np.quantile(cal, min(1, np.ceil((len(cal) + 1) * (1 - a_)) / len(cal)), method="higher")
        conf.append({"nominal_coverage": 1 - a_, "half_width_log10": float(q), "factor_band": float(10 ** q),
                     "empirical_test_coverage": float(np.mean(np.abs(yt - pt) <= q)), "covered_cases": int(np.sum(np.abs(yt - pt) <= q))})
    REPORT["c9"] = {**out["random_forest"], "ridge": out["ridge"], "split_conformal": conf,
                    "model": "archived Table 7 predictions (multifidelity_correction_predictions.csv)"}


def main():
    import sys
    part = sys.argv[1] if len(sys.argv) > 1 else "all"
    train, val, test = load()
    for name, fn in (("c2", comment2), ("c3", comment3), ("c9", comment9)):
        if part in (name, "all"):
            fn(train, val, test)
    (OUT / f"summary_{part}.json").write_text(json.dumps(REPORT, indent=2, default=lambda o: o if not hasattr(o, "item") else o.item()), encoding="utf-8")
    print("done")


if __name__ == "__main__":
    main()
