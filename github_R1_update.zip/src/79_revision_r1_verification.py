"""Independent re-computation of the headline revision numbers (different code paths than src/70-78)."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import r2_score

ROOT = Path(__file__).resolve().parents[1]
B = ROOT / "results" / "operator_v1"
R1 = B / "revision_r1"
checks = []


def chk(name, got, expected, tol):
    ok = bool(abs(got - expected) <= tol)
    checks.append({"check": name, "recomputed": float(got), "reported": float(expected), "tolerance": tol, "pass": ok})


t = pd.read_csv(B / "multifidelity_correction" / "multifidelity_training_table.csv")
tr, te = t[t.split == "train"], t[t.split == "test"]
# 1 leakage: splits disjoint in ROI and block; counts
checks.append({"check": "train/validation/test ROI sets disjoint", "pass": bool(len(set(tr.roi_id) & set(te.roi_id)) == 0 and len(set(t[t.split == 'validation'].roi_id) & set(te.roi_id)) == 0)})
checks.append({"check": "test ROIs all in block 3, train ROIs in blocks 0-1", "pass": bool(te.roi_id.str.contains("_B03_").all() and tr.roi_id.str.contains("_B0[01]_").all())})
chk("train cases", len(tr), 72, 0); chk("test cases", len(te), 36, 0); chk("test ROIs", te.roi_id.nunique(), 12, 0)
# 2 training table agrees with the raw CFD result tables
l1 = pd.read_csv(B / "operator_dataset" / "operator_l1_4x_cfd_permeability_dataset.csv")[["roi_id", "flow_axis", "log10_permeability_m2"]]
l2 = pd.read_csv(B / "operator_dataset" / "operator_l2_2x_cfd_permeability_dataset.csv")[["roi_id", "flow_axis", "log10_permeability_m2"]]
m = t.merge(l1, on=["roi_id", "flow_axis"]).merge(l2, on=["roi_id", "flow_axis"], suffixes=("_l1", "_l2"))
chk("max |L1 table - raw L1 CFD| (log10)", float(np.abs(m.log10_l1_k - m.log10_permeability_m2_l1).max()), 0, 1e-9)
chk("max |L2 table - raw L2 CFD| (log10)", float(np.abs(m.log10_l2_k - m.log10_permeability_m2_l2).max()), 0, 1e-9)
chk("matched cases", len(m), 144, 0)
# 3 Table 7 from the ARCHIVED prediction file (not refitted)
ap = pd.read_csv(B / "multifidelity_correction" / "multifidelity_correction_predictions.csv")
a = ap[(ap.model == "random_forest") & (ap.split == "test")]
chk("Table 7 RF R2 (archived predictions, sklearn r2_score)", r2_score(a.true_log10_l2, a.predicted_log10_l2), 0.867, 0.0006)
chk("Table 7 uncorrected L1 R2", r2_score(a.true_log10_l2, a.uncorrected_log10_l1), 0.696, 0.0006)
chk("Table 8 improved cases (RF)", int((np.abs(a.true_log10_l2 - a.predicted_log10_l2) < np.abs(a.true_log10_l2 - a.uncorrected_log10_l1)).sum()), 26, 0)
# 4 linear calibration by an independent routine (np.polyfit)
b1, b0 = np.polyfit(tr.log10_l1_k, tr.log10_l2_k, 1)
pl = b0 + b1 * te.log10_l1_k
chk("linear calibration slope", b1, 0.806, 0.0006); chk("linear calibration intercept", b0, -2.18, 0.006)
chk("linear calibration test R2", r2_score(te.log10_l2_k, pl), 0.836, 0.0006)
chk("constant shift test R2", r2_score(te.log10_l2_k, te.log10_l1_k + (tr.log10_l2_k - tr.log10_l1_k).mean()), 0.791, 0.0006)
# 5 ROI-level Wilcoxon RF vs uncorrected, from archived predictions
g = a.assign(e0=np.abs(a.true_log10_l2 - a.uncorrected_log10_l1), e1=np.abs(a.true_log10_l2 - a.predicted_log10_l2)).groupby("roi_id")[["e0", "e1"]].mean()
chk("ROIs improved by RF (archived model)", int((g.e0 > g.e1).sum()), 9, 0)
chk("ROI Wilcoxon one-sided p (archived model)", stats.wilcoxon(g.e0 - g.e1, alternative="greater").pvalue, 0.008, 0.0006)
# 6 L3: Darcy permeability recomputed from raw flux / pressure of every case
plan = pd.read_csv(R1 / "l3_expansion" / "l3_expansion_plan.csv"); rows = []
for r in plan.itertuples():
    s = json.loads((B / "openfoam_cases" / "L3_1x_cfd" / "test" / f"{r.roi_id}_{r.flow_axis}" / "flow_summary.json").read_text())
    k = s["conservative_flow_rate_m3_s"] * s["kinematic_viscosity_m2_s"] * s["sample_length_m"] / (s["bulk_area_mean_m2"] * s["pressure_drop_kinematic_m2_s2"])
    rows.append({"roi_id": r.roi_id, "flow_axis": r.flow_axis, "k": k, "k_file": s["darcy_permeability_m2"], "conv": s["solver_converged"], "imb": s["relative_flow_imbalance_percent"]})
L = pd.DataFrame(rows).merge(te[["roi_id", "flow_axis", "log10_l1_k", "log10_l2_k"]], on=["roi_id", "flow_axis"])
chk("L3 cases matched to test cases", len(L), 36, 0)
chk("L3 max relative diff: Darcy from raw flux vs stored k", float(np.abs(L.k / L.k_file - 1).max()), 0, 1e-9)
checks.append({"check": "all 36 L3 converged, imbalance < 0.1%", "pass": bool(L.conv.all() and (L.imb < 0.1).all())})
y = np.log10(L.k)
chk("median L1/L3", np.median(10 ** (L.log10_l1_k - y)), 1.13, 0.006); chk("median L2/L3", np.median(10 ** (L.log10_l2_k - y)), 1.26, 0.006)
chk("Spearman L1 vs L3", stats.spearmanr(L.log10_l1_k, y)[0], 0.88, 0.006); chk("Spearman L2 vs L3", stats.spearmanr(L.log10_l2_k, y)[0], 0.97, 0.006)
chk("L2 closer to L3 than L1 (cases)", int((np.abs(L.log10_l2_k - y) < np.abs(L.log10_l1_k - y)).sum()), 6, 0)
chk("median L2/L1 on test split", np.median(10 ** (te.log10_l2_k - te.log10_l1_k)), 1.12, 0.006)
out = pd.DataFrame(checks); out.to_csv(R1 / "verification_checks.csv", index=False)
pd.set_option("display.width", 200); print(out.to_string(index=False)); print("ALL PASS" if out["pass"].all() else "FAILURES PRESENT")
