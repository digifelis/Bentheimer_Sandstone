"""Reviewer-1 comments 5 and 13: why is the fidelity ordering non-monotonic on the 36-case L3 set?

Links the L1/L2/L3 permeability differences to the connected-pore (mesh) porosity of each tier
(6-connectivity, from src/73), reports per-axis results, rank agreement, and leave-one-ROI-out
offset calibration of each tier toward L3 (descriptive only; L3 exists for the test block only).
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "results" / "operator_v1"
EXP = BASE / "revision_r1" / "l3_expansion"


def main():
    m = pd.read_csv(EXP / "l3_expansion_cases.csv")
    m = m[m.status == "accepted"].copy()
    m["log_l3"] = np.log10(m.k_l3)
    con = pd.read_csv(BASE / "revision_r1" / "connectivity" / "connectivity_per_roi_axis.csv")
    con = con[con.connectivity == 6].pivot_table(index=["roi_id", "flow_axis"], columns="coarsening", values="mesh_porosity").reset_index()
    con.columns = ["roi_id", "flow_axis", "phi_l3", "phi_l2", "phi_l1"]
    m = m.merge(con, on=["roi_id", "flow_axis"])
    rep = {"n_cases": int(len(m)), "n_rois": int(m.roi_id.nunique())}
    # ordering patterns
    l1, l2, l3 = m.log10_l1_k, m.log10_l2_k, m.log_l3
    pat = np.select([(l3 < l1) & (l1 < l2), (l3 < l2) & (l2 < l1), (l1 < l3) & (l3 < l2), (l1 < l2) & (l2 < l3), (l2 < l1) & (l1 < l3), (l2 < l3) & (l3 < l1)],
                    ["L3 < L1 < L2", "L3 < L2 < L1", "L1 < L3 < L2", "L1 < L2 < L3 (monotonic)", "L2 < L1 < L3", "L2 < L3 < L1"], "tie")
    rep["ordering_patterns"] = pd.Series(pat).value_counts().to_dict()
    # mesh porosity per tier
    rep["mesh_porosity_mean"] = {"L1": float(m.phi_l1.mean()), "L2": float(m.phi_l2.mean()), "L3": float(m.phi_l3.mean())}
    rep["mesh_porosity_relative_to_L3_pct_median"] = {"L1": float(100 * (m.phi_l1 / m.phi_l3 - 1).median()), "L2": float(100 * (m.phi_l2 / m.phi_l3 - 1).median())}
    rep["cases_phi_l2_gt_phi_l3"] = int((m.phi_l2 > m.phi_l3).sum()); rep["cases_phi_l1_lt_phi_l3"] = int((m.phi_l1 < m.phi_l3).sum())
    # association of permeability offset with porosity offset
    assoc = {}
    for t, lk, ph in (("L1", l1, m.phi_l1), ("L2", l2, m.phi_l2)):
        s = stats.spearmanr(np.log10(ph / m.phi_l3), lk - l3)
        assoc[t] = {"spearman_rho": float(s.statistic), "p": float(s.pvalue)}
    rep["log_k_offset_vs_log_mesh_porosity_offset"] = assoc
    # per axis
    ax = []
    for a, g in m.groupby("flow_axis"):
        for t, col in (("L1", "log10_l1_k"), ("L2", "log10_l2_k")):
            e = g[col] - g.log_l3
            ax.append({"axis": a, "tier": t, "median_ratio_to_L3": float(np.median(10 ** e)), "rmse_log10": float(np.sqrt(np.mean(e ** 2)))})
    pd.DataFrame(ax).to_csv(EXP / "l3_per_axis.csv", index=False); rep["per_axis"] = ax
    # leave-one-ROI-out calibration toward L3 (offset and linear) - descriptive
    loo = {}
    for t, col in (("L1", "log10_l1_k"), ("L2", "log10_l2_k"), ("RF-corrected L1", "RF, L1 + morphology + axis (Table 7)"), ("linear-calibrated L1", "linear calibration (a + b*L1)")):
        po, pl = np.empty(len(m)), np.empty(len(m))
        for r in m.roi_id.unique():
            tr, te = (m.roi_id != r).to_numpy(), (m.roi_id == r).to_numpy()
            x, y = m[col].to_numpy(), m.log_l3.to_numpy()
            po[te] = x[te] + np.mean(y[tr] - x[tr])
            b, a = np.polyfit(x[tr], y[tr], 1); pl[te] = a + b * x[te]
        y = m.log_l3.to_numpy(); x = m[col].to_numpy()
        loo[t] = {"raw_rmse": float(np.sqrt(np.mean((x - y) ** 2))), "loro_offset_rmse": float(np.sqrt(np.mean((po - y) ** 2))),
                  "loro_linear_rmse": float(np.sqrt(np.mean((pl - y) ** 2))), "spearman": float(stats.spearmanr(x, y).statistic),
                  "pearson_r2_log": float(stats.pearsonr(x, y).statistic ** 2)}
    rep["leave_one_roi_out_calibration_to_L3"] = loo
    m.to_csv(EXP / "l3_mechanism_cases.csv", index=False)
    (EXP / "l3_mechanism_summary.json").write_text(json.dumps(rep, indent=2), encoding="utf-8")
    print(json.dumps(rep, indent=1))


if __name__ == "__main__":
    main()
