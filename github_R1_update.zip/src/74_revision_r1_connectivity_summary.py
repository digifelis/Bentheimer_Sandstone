"""Summarise src/73 output: mesh reproduction check, 6/18/26 sensitivity, link to L2/L1 bias."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "results" / "operator_v1"
OUT = BASE / "revision_r1" / "connectivity"
raw = pd.read_csv(OUT / "connectivity_per_roi_axis.csv").drop_duplicates(["roi_id", "flow_axis", "connectivity", "coarsening"])
rep: dict = {"rois": int(raw.roi_id.nunique()), "roi_axis_cases": int(raw[["roi_id", "flow_axis"]].drop_duplicates().shape[0])}

# 1. reproduction of archived mesh cell counts (6-connectivity)
mf = pd.read_csv(BASE / "fractal_xai" / "multifidelity_training_table_with_fractals.csv")[["roi_id", "flow_axis", "cells_l1_4x", "cells_l2_2x"]]
six = raw[raw.connectivity == 6].pivot_table(index=["roi_id", "flow_axis"], columns="coarsening", values="mesh_cells").reset_index()
chk = mf.merge(six, on=["roi_id", "flow_axis"])
rep["mesh_reproduction"] = {"cases": int(len(chk)),
                            "l1_exact_matches": int((chk.cells_l1_4x == chk[4]).sum()),
                            "l2_exact_matches": int((chk.cells_l2_2x == chk[2]).sum())}

# 2. sensitivity table
piv = raw.pivot_table(index=["roi_id", "flow_axis", "coarsening"], columns="connectivity", values="mesh_porosity").reset_index()
perc = raw.pivot_table(index=["roi_id", "flow_axis", "coarsening"], columns="connectivity", values="percolates", aggfunc="first").reset_index()
rows = []
for f, label in ((1, "L3/1x (native)"), (2, "L2/2x"), (4, "L1/4x")):
    p, q = piv[piv.coarsening == f], perc[perc.coarsening == f]
    b = raw[(raw.coarsening == f)]
    for c in (6, 18, 26):
        rel = 100 * (p[c] - p[6]) / p[6]
        bb = b[b.connectivity == c]
        rows.append({"fidelity": label, "connectivity": c,
                     "percolating_cases": int(q[c].astype(bool).sum()), "cases": int(len(q)),
                     "mean_mesh_porosity": float(p[c].mean()),
                     "retained_fraction_of_image_pore_mean": float(bb.stage1_fraction_of_pore.mean()),
                     "rel_change_vs_6_pct_median": float(rel.median()), "rel_change_vs_6_pct_p95": float(rel.quantile(0.95)),
                     "rel_change_vs_6_pct_max": float(rel.max()),
                     "diagonal_bridges_per_1000_cells_median": float((1000 * bb.diagonal_bridges_in_mesh_set / bb.mesh_cells).median()) if c > 6 else 0.0})
tab = pd.DataFrame(rows); tab.to_csv(OUT / "connectivity_sensitivity_summary.csv", index=False)

# 3. does the connectivity-dependent difference track the L2/L1 permeability bias?
t = pd.read_csv(BASE / "multifidelity_correction" / "multifidelity_training_table.csv")
t["log_ratio"] = t.log10_l2_k - t.log10_l1_k
d = piv.pivot_table(index=["roi_id", "flow_axis"], columns="coarsening", values=[6, 26]).reset_index()
d.columns = ["roi_id", "flow_axis"] + [f"phi{c}_f{f}" for c, f in d.columns.tolist()[2:]]
d["gain26_l1"] = d.phi26_f4 / d.phi6_f4 - 1
d["gain26_l2"] = d.phi26_f2 / d.phi6_f2 - 1
d["mesh_porosity_ratio_l2_l1"] = np.log10(d.phi6_f2 / d.phi6_f4)
m = t.merge(d, on=["roi_id", "flow_axis"])
corr = {}
for col in ("gain26_l1", "gain26_l2", "mesh_porosity_ratio_l2_l1"):
    s = stats.spearmanr(m[col], m.log_ratio)
    corr[col] = {"spearman_rho": float(s.statistic), "p": float(s.pvalue)}
rep["link_to_l2_over_l1_bias_144_cases"] = corr
rep["summary_table"] = tab.to_dict(orient="records")
(OUT / "connectivity_summary.json").write_text(json.dumps(rep, indent=2), encoding="utf-8")
pd.set_option("display.width", 250)
print(json.dumps({k: v for k, v in rep.items() if k != "summary_table"}, indent=1))
print(tab.round(4).to_string(index=False))
