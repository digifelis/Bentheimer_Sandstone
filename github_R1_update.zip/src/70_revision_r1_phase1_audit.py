"""Reviewer-1 revision, phase 1: audit of the L1-to-L2 correction evidence.

1. Reproduce the Table 7 random-forest correction (src/69) and check it against the archive.
2. Recompute feature importance from that same model (fixes the Table 9 model mismatch).
3. Re-run the archived fractal-XAI configuration to document where the old Table 9 came from.
4. Document the RF hyperparameters and training protocol (Reviewer comment 2).
5. Reproduce the L2 subset selection and compare it with the full split (comment 4).
6. Document block geometry and block-boundary adjacency (comments 3 and 12).
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn
from scipy import stats
from sklearn.ensemble import RandomForestRegressor
from sklearn.inspection import permutation_importance
from sklearn.metrics import mean_squared_error, r2_score

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "results" / "operator_v1"
OUT = BASE / "revision_r1" / "phase1"
OUT.mkdir(parents=True, exist_ok=True)

MAIN_FEATURES = [
    "log10_l1_k", "porosity", "largest_component_fraction_of_pore",
    "log10_connected_components_6", "axis_x", "axis_y", "axis_z",
]
FRACTAL_EXTRA = ["interface_box_counting_dimension", "lacunarity_mean"]
GROUPS = {
    "L1 permeability": ["log10_l1_k"],
    "morphology (porosity, connectivity)": ["porosity", "largest_component_fraction_of_pore", "log10_connected_components_6"],
    "flow axis": ["axis_x", "axis_y", "axis_z"],
}
BLOCK_Z = 360  # slices per NetCDF block


def main_rf(seed: int = 1701) -> RandomForestRegressor:
    return RandomForestRegressor(n_estimators=500, min_samples_leaf=2, random_state=seed, n_jobs=-1)


def score(y, p) -> dict:
    return {"r2": float(r2_score(y, p)), "rmse": float(np.sqrt(mean_squared_error(y, p)))}


def group_permutation(model, x: pd.DataFrame, y: np.ndarray, cols: list[str], repeats: int, rng) -> tuple[float, float]:
    base = r2_score(y, model.predict(x))
    drops = []
    for _ in range(repeats):
        xp = x.copy()
        idx = rng.permutation(len(xp))
        xp[cols] = xp[cols].to_numpy()[idx]
        drops.append(base - r2_score(y, model.predict(xp)))
    return float(np.mean(drops)), float(np.std(drops))


def importance_table(model, x_test, y_test, features, seed) -> pd.DataFrame:
    perm = permutation_importance(model, x_test, y_test, n_repeats=100, random_state=seed, n_jobs=-1, scoring="r2")
    out = pd.DataFrame({
        "feature": features,
        "gini_importance": model.feature_importances_,
        "permutation_r2_drop_mean": perm.importances_mean,
        "permutation_r2_drop_sd": perm.importances_std,
    }).sort_values("permutation_r2_drop_mean", ascending=False)
    pos = out["permutation_r2_drop_mean"].clip(lower=0)
    out["positive_permutation_share"] = pos / pos.sum()
    return out


def main() -> None:
    report: dict = {"sklearn_version": sklearn.__version__}
    table = pd.read_csv(BASE / "multifidelity_correction" / "multifidelity_training_table.csv")
    frac = pd.read_csv(BASE / "fractal_xai" / "multifidelity_training_table_with_fractals.csv")
    train, test = table[table.split == "train"], table[table.split == "test"]
    y_tr, y_te = train["log10_l2_k"].to_numpy(), test["log10_l2_k"].to_numpy()

    # 1. reproduce Table 7
    archived = pd.read_csv(BASE / "multifidelity_correction" / "multifidelity_correction_metrics.csv")
    arch_rf = archived[(archived.model == "random_forest") & (archived.split == "test")].iloc[0]
    rf = main_rf().fit(train[MAIN_FEATURES], y_tr)
    pred = rf.predict(test[MAIN_FEATURES])
    report["table7_reproduction"] = {
        "archived_test_r2": float(arch_rf.r2_log10), "reproduced_test_r2": score(y_te, pred)["r2"],
        "archived_test_rmse": float(arch_rf.rmse_log10), "reproduced_test_rmse": score(y_te, pred)["rmse"],
        "uncorrected_l1_test": score(y_te, test["log10_l1_k"].to_numpy()),
        "n_train_cases": int(len(train)), "n_train_rois": int(train.roi_id.nunique()),
        "n_test_cases": int(len(test)), "n_test_rois": int(test.roi_id.nunique()),
    }

    # 2. importance from the SAME model as Table 7
    imp = importance_table(rf, test[MAIN_FEATURES], y_te, MAIN_FEATURES, 1701)
    imp.to_csv(OUT / "main_model_feature_importance.csv", index=False)
    rng = np.random.default_rng(1701)
    grp = [{"group": g, "permutation_r2_drop_mean": m, "permutation_r2_drop_sd": s}
           for g, cols in GROUPS.items()
           for m, s in [group_permutation(rf, test[MAIN_FEATURES], y_te, cols, 200, rng)]]
    pd.DataFrame(grp).to_csv(OUT / "main_model_group_importance.csv", index=False)
    # drop-column (refit) importance: how much test R2 is lost if a feature group is removed
    drop = []
    for g, cols in GROUPS.items():
        feats = [f for f in MAIN_FEATURES if f not in cols]
        r = []
        for s in range(1701, 1711):
            m = main_rf(s).fit(train[feats], y_tr)
            r.append(r2_score(y_te, m.predict(test[feats])))
        drop.append({"removed_group": g, "test_r2_mean_10seeds": float(np.mean(r)), "test_r2_sd": float(np.std(r))})
    full = [r2_score(y_te, main_rf(s).fit(train[MAIN_FEATURES], y_tr).predict(test[MAIN_FEATURES])) for s in range(1701, 1711)]
    drop.insert(0, {"removed_group": "none (full model)", "test_r2_mean_10seeds": float(np.mean(full)), "test_r2_sd": float(np.std(full))})
    pd.DataFrame(drop).to_csv(OUT / "main_model_drop_group_refit.csv", index=False)

    # 3. fractal descriptors evaluated under the SAME protocol (train only) vs archived Table 9 protocol
    ftr, fte = frac[frac.split == "train"], frac[frac.split == "test"]
    ffeat = MAIN_FEATURES[:4] + FRACTAL_EXTRA + MAIN_FEATURES[4:]
    fr = [r2_score(fte.log10_l2_k, main_rf(s).fit(ftr[ffeat], ftr.log10_l2_k).predict(fte[ffeat])) for s in range(1701, 1711)]
    old = RandomForestRegressor(n_estimators=600, max_depth=None, min_samples_leaf=2, random_state=1729, n_jobs=-1)
    trv = frac[frac.split.isin(["train", "validation"])]
    old.fit(trv[ffeat], trv.log10_l2_k)
    report["fractal_descriptors"] = {
        "main_protocol_with_fractals_test_r2_mean_10seeds": float(np.mean(fr)),
        "main_protocol_with_fractals_test_r2_sd": float(np.std(fr)),
        "main_protocol_without_fractals_test_r2_mean_10seeds": float(np.mean(full)),
        "archived_table9_protocol": "600 trees, seed 1729, trained on train+validation (108 cases), 9 features incl. box-counting dimension and lacunarity",
        "archived_table9_protocol_reproduced_test_r2": float(r2_score(fte.log10_l2_k, old.predict(fte[ffeat]))),
    }
    fm = main_rf().fit(ftr[ffeat], ftr.log10_l2_k)
    importance_table(fm, fte[ffeat], fte.log10_l2_k.to_numpy(), ffeat, 1701).to_csv(OUT / "main_protocol_with_fractals_importance.csv", index=False)

    # 4. hyperparameters / protocol
    params = {k: (v if isinstance(v, (int, float, str, bool, type(None))) else str(v)) for k, v in rf.get_params().items()}
    report["rf_hyperparameters"] = params
    report["rf_protocol"] = {
        "tuned": False,
        "selection": "fixed a priori (500 trees, min_samples_leaf=2, all other scikit-learn defaults); no grid or random search",
        "validation_block_used_for_tuning": False,
        "fit_data": "training blocks only (72 L2 ROI-axis cases from 24 ROIs)",
        "retrained_on_train_plus_validation": False,
        "max_features_effective": "all 7 features at every split (scikit-learn regressor default 1.0)",
        "mean_tree_depth": float(np.mean([e.get_depth() for e in rf.estimators_])),
        "mean_leaves_per_tree": float(np.mean([e.get_n_leaves() for e in rf.estimators_])),
    }

    # 5. L2 subset selection
    reg = pd.read_csv(BASE / "roi_registry" / "operator_roi_registry_accepted.csv")
    reg = reg[reg.accepted_for_operator.astype(bool)]
    sel = pd.read_csv(BASE / "experiment_plan" / "selected_rois_l2_2x_cfd.csv")
    rows, recon = [], []
    for split, n in [("train", 24), ("validation", 12), ("test", 12)]:
        o = reg[reg.split == split].sort_values(["porosity", "roi_id"]).reset_index(drop=True)
        pos = sorted(set(round(i * (len(o) - 1) / (n - 1)) for i in range(n)))
        recon += o.iloc[pos].roi_id.tolist()
        s = sel[sel.split == split]
        ks = stats.ks_2samp(s.porosity, o.porosity)
        rows.append({"split": split, "pool_rois": len(o), "selected_rois": len(s),
                     "pool_porosity_mean": o.porosity.mean(), "selected_porosity_mean": s.porosity.mean(),
                     "pool_porosity_min": o.porosity.min(), "pool_porosity_max": o.porosity.max(),
                     "selected_porosity_min": s.porosity.min(), "selected_porosity_max": s.porosity.max(),
                     "ks_statistic": ks.statistic, "ks_p": ks.pvalue})
    pd.DataFrame(rows).to_csv(OUT / "l2_selection_vs_pool.csv", index=False)
    # L1 permeability distribution of selected vs unselected (outcome-blind check)
    l1 = pd.read_csv(BASE / "fidelity_comparison" / "l1_l2_matched_permeability.csv") if False else None
    report["l2_selection"] = {
        "algorithm": "within each split, accepted ROIs sorted by (porosity, roi_id); n ROIs taken at evenly spaced rank positions round(i*(N-1)/(n-1)); all three flow axes simulated for each selected ROI",
        "n_rois": {"train": 24, "validation": 12, "test": 12},
        "selection_variable": "porosity only (computed from the segmented image); no permeability information used",
        "reconstruction_matches_archive": sorted(recon) == sorted(sel.roi_id.tolist()),
    }

    # 6. block geometry and boundary adjacency
    blocks = reg.groupby("block_index").agg(split=("split", "first"), z_global_start=("z_start_global", "min"),
                                             z_global_end=("z_end_global", "max"), rois=("roi_id", "size")).reset_index()
    blocks.to_csv(OUT / "block_geometry.csv", index=False)
    reg = reg.copy()
    reg["dist_to_lower_block_face"] = reg.z_start_local
    reg["dist_to_upper_block_face"] = BLOCK_Z - reg.z_end_local
    split_of = dict(zip(blocks.block_index, blocks.split))

    def gap_to_other_split(r) -> float:
        d = []
        lo, hi = r.block_index - 1, r.block_index + 1
        if lo in split_of and split_of[lo] != r.split:
            d.append(r.dist_to_lower_block_face)
        if hi in split_of and split_of[hi] != r.split:
            d.append(r.dist_to_upper_block_face)
        return min(d) if d else np.nan
    reg["gap_to_other_split_voxels"] = reg.apply(gap_to_other_split, axis=1)
    reg["in_l2_subset"] = reg.roi_id.isin(sel.roi_id)
    reg[["roi_id", "block_index", "split", "z_start_local", "z_end_local", "porosity", "in_l2_subset", "gap_to_other_split_voxels"]].to_csv(OUT / "roi_boundary_gaps.csv", index=False)
    summ = []
    for (split, l2), g in reg.groupby(["split", "in_l2_subset"]):
        gg = g.gap_to_other_split_voxels
        summ.append({"split": split, "in_l2_subset": bool(l2), "rois": len(g), "touching_other_split(gap=0)": int((gg == 0).sum()),
                     "gap<=40": int((gg <= 40).sum()), "gap<=80": int((gg <= 80).sum()), "min_gap": float(gg.min()) if gg.notna().any() else None})
    pd.DataFrame(summ).to_csv(OUT / "boundary_adjacency_summary.csv", index=False)
    report["block_geometry"] = {
        "note": "blocks 0-3 are contiguous 360-slice z-segments of one DRP-236 specimen scan; adjacent splits share a face (block1|block2 at z=720 train|validation, block2|block3 at z=1080 validation|test)",
        "blocks": blocks.to_dict(orient="records"),
    }
    (OUT / "phase1_audit_summary.json").write_text(json.dumps(report, indent=2, default=float), encoding="utf-8")
    print(json.dumps(report, indent=2, default=float))


if __name__ == "__main__":
    main()
