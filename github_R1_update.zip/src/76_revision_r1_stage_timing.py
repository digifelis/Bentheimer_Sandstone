"""Reviewer-1 comment 10: stage-resolved timing of case preparation and descriptor extraction.

Times, on the same CPU used for the archived solves (Intel i7-12650H; Linux VM, 2 vCPU),
for the 12 L2 test-block ROIs (x axis): NetCDF read + percolation + coarsening + OpenFOAM case
writing for L1/4x, L2/2x and (3 ROIs) L3/1x, plus morphology-descriptor extraction.
Cases are written to a local temporary directory and removed. Resumable (appends to CSV).
"""
from __future__ import annotations

import shutil
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.ndimage import generate_binary_structure, label

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from bentheimer.data import NetCDFVolumeReader  # noqa: E402
from bentheimer.operator_cases import prepare_operator_case  # noqa: E402

BASE = ROOT / "results" / "operator_v1"
OUT = BASE / "revision_r1" / "cost"
OUT.mkdir(parents=True, exist_ok=True)
RAW = OUT / "stage_timing_raw.csv"
BUDGET = float(sys.argv[1]) if len(sys.argv) > 1 else 150


def main():
    plan = pd.read_csv(BASE / "experiment_plan" / "operator_fidelity_plan.csv")
    tests = sorted(pd.read_csv(BASE / "experiment_plan" / "selected_rois_l2_2x_cfd.csv").query("split=='test'").roi_id)
    base = plan[(plan.fidelity == "L2_2x_cfd") & plan.roi_id.isin(tests) & (plan.flow_axis == "x")]
    jobs = [(r, "L1_4x_cfd", 4) for r in tests] + [(r, "L2_2x_cfd", 2) for r in tests] + [(r, "L3_1x_cfd", 1) for r in tests[:3]] + [(r, "descriptors", 0) for r in tests]
    done = set(map(tuple, pd.read_csv(RAW)[["roi_id", "stage"]].values)) if RAW.exists() else set()
    reader = NetCDFVolumeReader(ROOT / "dataset" / "DRP-236" / "Bentheimer Sandstone", "segmented", (4.95, 4.95, 4.95))
    t0 = time.time(); rows = []
    for roi, stage, f in jobs:
        if (roi, stage) in done:
            continue
        if time.time() - t0 > BUDGET:
            break
        task = base[base.roi_id == roi].iloc[0].copy()
        if stage == "descriptors":
            s = time.perf_counter()
            seg, _ = reader.read([int(task.block_index)], [int(task.z_start_local), int(task.z_end_local)],
                                 [int(task.y_start), int(task.y_end)], [int(task.x_start), int(task.x_end)])
            pore = np.isin(seg, (0, 2)); lab, n = label(pore, structure=generate_binary_structure(3, 1))
            sizes = np.bincount(lab.ravel())[1:]; _ = (pore.mean(), sizes.max() / pore.sum(), np.log10(n))
            rows.append({"roi_id": roi, "stage": stage, "wall_s": time.perf_counter() - s, "cells": np.nan, "case_mb": np.nan})
        else:
            task["fidelity"] = stage; task["coarsening_factor"] = f; task["task_id"] = f"{stage}_{roi}_x"
            tmp = Path(tempfile.mkdtemp(prefix="tim_", dir="/tmp"))
            s = time.perf_counter()
            man = prepare_operator_case(task, reader, tmp, pore_fraction_threshold=0.5, overwrite=True)
            w = time.perf_counter() - s
            mb = sum(p.stat().st_size for p in tmp.rglob("*") if p.is_file()) / 1e6
            cells = man.get("pore_cells", man.get("cells", np.nan))
            shutil.rmtree(tmp)
            rows.append({"roi_id": roi, "stage": f"prepare_{stage}", "wall_s": w, "cells": cells, "case_mb": mb})
        pd.DataFrame(rows[-1:]).to_csv(RAW, mode="a", header=not RAW.exists(), index=False)
    left = len(jobs) - len(done) - len(rows)
    print(f"timed {len(rows)} jobs; remaining {left}")


if __name__ == "__main__":
    main()
