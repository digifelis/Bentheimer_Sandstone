"""Revision figures: Figure 9 (feature importance of the Table 7 random forest) and Figure 11b (native-resolution comparison)."""
from __future__ import annotations
import sys
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
R1 = ROOT / "results" / "operator_v1" / "revision_r1"
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "figures" / "paper"
OUT.mkdir(parents=True, exist_ok=True)

d = pd.read_csv(R1 / "phase1" / "main_model_feature_importance.csv").sort_values("permutation_r2_drop_mean")
fig, ax = plt.subplots(figsize=(2058 / 300, 1228 / 300), dpi=300)
ax.barh(d.feature, d.permutation_r2_drop_mean.clip(lower=0), xerr=d.permutation_r2_drop_sd, color="#4C78A8", ecolor="#333333", capsize=2, error_kw=dict(lw=0.8))
for y, (m, s) in enumerate(zip(d.permutation_r2_drop_mean, d.permutation_r2_drop_sd)):
    ax.text(max(m, 0) + s + 0.03, y, f"{m + 1e-9:.3f}", va="center", fontsize=7)
ax.set_xlabel("Permutation importance: R^2 decrease (mean +/- SD)"); ax.set_title("L1-to-L2 correction feature importance")
ax.grid(axis="x", alpha=0.3); ax.set_axisbelow(True); ax.set_xlim(-0.05, 2.05)
fig.tight_layout(); fig.savefig(OUT / "fig09_feature_importance_R1.png", dpi=300, facecolor="white", metadata={"Software": None}); plt.close(fig)

m = pd.read_csv(R1 / "l3_expansion" / "l3_mechanism_cases.csv"); x = m.log_l3; rf = "RF, L1 + morphology + axis (Table 7)"
fig, (a, b) = plt.subplots(1, 2, figsize=(8, 3.5), dpi=300, gridspec_kw=dict(width_ratios=[1.25, 1]))
for col, lab, c, mk in [("log10_l1_k", "L1/4x CFD", "#D95F0E", "o"), ("log10_l2_k", "L2/2x CFD", "#2C7FB8", "s"), (rf, "RF-corrected L1", "#54A24B", "^")]:
    a.scatter(x, m[col], s=14, c=c, marker=mk, label=f"{lab} (Spearman {stats.spearmanr(m[col], x)[0]:.2f})", alpha=0.85, edgecolors="none")
lo, hi = min(x.min(), m.log10_l1_k.min()) - 0.05, max(m.log10_l2_k.max(), m[rf].max()) + 0.05
a.plot([lo, hi], [lo, hi], "k--", lw=0.8, label="1:1"); a.set_xlim(lo, hi); a.set_ylim(lo, hi)
a.set_xlabel("log10 k, native L3/1x CFD (m^2)", fontsize=7); a.set_ylabel("log10 k, coarsened or corrected (m^2)", fontsize=7)
a.set_title("(a) Test block, 36 cases / 12 ROIs", fontsize=7.5); a.legend(fontsize=5.5, loc="upper left", frameon=False); a.tick_params(labelsize=6)
v = [100 * (m.phi_l1 / m.phi_l3 - 1), 100 * (m.phi_l2 / m.phi_l3 - 1)]
bp = b.boxplot(v, widths=0.5, patch_artist=True, medianprops=dict(color="k"), showfliers=False)
for p, c in zip(bp["boxes"], ["#D95F0E", "#2C7FB8"]):
    p.set_facecolor(c); p.set_alpha(0.6)
for i, q in enumerate(v, 1):
    b.scatter(np.random.default_rng(1).normal(i, 0.05, len(q)), q, s=5, c="k", alpha=0.5)
b.axhline(0, color="k", lw=0.8, ls="--"); b.set_xticks([1, 2]); b.set_xticklabels(["L1/4x", "L2/2x"], fontsize=7)
b.set_ylabel("Connected-pore (mesh) porosity\nrelative to L3 (%)", fontsize=7); b.set_title("(b) Connected porosity after coarsening", fontsize=7.5); b.tick_params(labelsize=6)
fig.tight_layout(); fig.savefig(OUT / "fig11b_native_comparison_R1.png", dpi=300, facecolor="white", metadata={"Software": None}); plt.close(fig)
print("figures written to", OUT)
