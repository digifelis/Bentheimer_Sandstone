"""Reviewer-1 comment 5 (and 13): expanded native L3/1x comparison on the independent test block.

Collects finished L3 cases from the expansion plan (36 = 12 L2-test ROIs x 3 axes), applies the
manuscript acceptance criteria and compares L1, L2, the linear L1 calibration and the RF correction
(both trained on the training blocks to predict L2) against L3 in log10 permeability.
Uncertainty: ROI-clustered bootstrap. Works on partial results.
"""
from __future__ import annotations

import importlib.util
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "results" / "operator_v1"
EXP = BASE / "revision_r1" / "l3_expansion"
CASES = BASE / "openfoam_cases" / "L3_1x_cfd" / "test"
spec = importlib.util.spec_from_file_location("c", ROOT / "scripts" / "collect_openfoam_roi.py")
mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)


def finished(case: Path) -> bool:
    log = case / "log.simpleFoam"
    return log.exists() and bool(re.search(r"^End\s*$", log.read_text(errors="replace")[-400:], re.M))


def wall_clock(case: Path) -> float:
    p = case / "log.resource_usage"
    if not p.exists():
        return np.nan
    m = re.search(r"Elapsed \(wall clock\) time \(h:mm:ss or m:ss\): ([\d:.]+)", p.read_text())
    if not m:
        return np.nan
    parts = [float(x) for x in m.group(1).split(":")]
    return sum(v * 60 ** i for i, v in enumerate(reversed(parts)))


def main() -> None:
    plan = pd.read_csv(EXP / "l3_expansion_plan.csv")
    rows = []
    for t in plan.itertuples():
        case = CASES / f"{t.roi_id}_{t.flow_axis}"
        if not finished(case):
            rows.append({"roi_id": t.roi_id, "flow_axis": t.flow_axis, "status": "not_finished"}); continue
        s = json.loads((case / "flow_summary.json").read_text()) if (case / "flow_summary.json").exists() else None
        if s is None or s.get("latest_time") != max(v for v, _ in mod.numeric_time_directories(case)):
            s = mod.collect(case); (case / "flow_summary.json").write_text(json.dumps(s, indent=2))
        acc = s.get("scientific_acceptance", {})
        ok = bool(s.get("solver_converged")) and all(acc.get(k) for k in ("finite_positive_permeability", "flow_imbalance_below_0_1_percent", "positive_pressure_drop"))
        rows.append({"roi_id": t.roi_id, "flow_axis": t.flow_axis, "status": "accepted" if ok else "rejected",
                     "k_l3": s["darcy_permeability_m2"], "l3_cells": s["cells"], "l3_converged": s.get("solver_converged"),
                     "l3_flow_imbalance_pct": s.get("relative_flow_imbalance_percent"), "l3_wall_clock_s": wall_clock(case)})
    l3 = pd.DataFrame(rows)
    pred = pd.read_csv(BASE / "revision_r1" / "recalibration_baselines" / "predictions_fit_train.csv")
    m = pred.merge(l3, on=["roi_id", "flow_axis"], how="left")
    m.to_csv(EXP / "l3_expansion_cases.csv", index=False)
    a = m[m.status == "accepted"].copy()
    rep = {"cases_in_plan": int(len(plan)), "finished": int((l3.status != "not_finished").sum()),
           "accepted": int(len(a)), "accepted_rois": int(a.roi_id.nunique())}
    if len(a) >= 3:
        y = np.log10(a.k_l3.to_numpy())
        tiers = {"L1 (4x CFD)": a.log10_l1_k, "L2 (2x CFD)": a.log10_l2_k,
                 "linear calibration (L1->L2)": a["linear calibration (a + b*L1)"],
                 "RF correction (L1->L2, Table 7)": a["RF, L1 + morphology + axis (Table 7)"]}
        rois = a.roi_id.to_numpy(); uniq = np.unique(rois); idx = {r: np.where(rois == r)[0] for r in uniq}
        rng = np.random.default_rng(1701)
        boots = [np.concatenate([idx[r] for r in rng.choice(uniq, len(uniq))]) for _ in range(5000)] if len(uniq) > 2 else []
        out = []
        for name, p in tiers.items():
            p = p.to_numpy(); e = p - y
            r = {"tier": name, "n": len(y), "mean_signed_error_log10": float(e.mean()),
                 "median_ratio_to_L3": float(np.median(10 ** e)), "mean_abs_pct_error": float(np.mean(np.abs(10 ** e - 1)) * 100),
                 "rmse_log10": float(np.sqrt(np.mean(e ** 2))), "spearman_with_L3": float(stats.spearmanr(p, y).statistic)}
            if boots:
                b = np.array([np.sqrt(np.mean((p[i] - y[i]) ** 2)) for i in boots])
                r["rmse_ci"] = [float(np.percentile(b, 2.5)), float(np.percentile(b, 97.5))]
            out.append(r)
        rep["comparison_vs_L3"] = out
        e1, e2 = np.abs(a.log10_l1_k - y), np.abs(a.log10_l2_k - y)
        rep["L2_closer_to_L3_than_L1"] = f"{int((e2 < e1).sum())}/{len(y)}"
        rep["monotonic_L1_L2_L3_cases"] = int((((a.log10_l1_k < a.log10_l2_k) & (a.log10_l2_k < y)) | ((a.log10_l1_k > a.log10_l2_k) & (a.log10_l2_k > y))).sum())
        rep["l3_wall_clock_s_median"] = float(a.l3_wall_clock_s.median())
        pd.DataFrame(out).to_csv(EXP / "l3_expansion_comparison.csv", index=False)
    (EXP / "l3_expansion_summary.json").write_text(json.dumps(rep, indent=2), encoding="utf-8")
    print(json.dumps(rep, indent=2))


if __name__ == "__main__":
    main()
