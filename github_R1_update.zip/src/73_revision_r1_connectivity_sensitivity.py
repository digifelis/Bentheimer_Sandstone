"""Reviewer-1 comment 6: sensitivity of the percolating pore space to 6/18/26-connectivity.

Re-implements the mesh-preparation path of `bentheimer.voxel_mesh.build_voxel_mesh` for every
accepted ROI and flow axis:  native pore mask -> percolating component (connectivity c) ->
block-average coarsening (threshold 0.5) -> percolating component (connectivity c).
For c in {6, 18, 26} and coarsening factor in {1 (L3), 2 (L2), 4 (L1)} it records the retained
pore fraction, percolation status and the number of edge/corner-only pore contacts
("diagonal bridges") that a face-based finite-volume mesh cannot transmit flow through.
Resumable: per-ROI rows are appended to a CSV (run repeatedly until all ROIs are done).
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.ndimage import generate_binary_structure, label

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from bentheimer.data import NetCDFVolumeReader  # noqa: E402

BASE = ROOT / "results" / "operator_v1"
OUT = BASE / "revision_r1" / "connectivity"
OUT.mkdir(parents=True, exist_ok=True)
RAW = OUT / "connectivity_per_roi_axis.csv"
PORE_LABELS = (0, 2)
CONN = {6: 1, 18: 2, 26: 3}
AXIS_DIM = {"z": 0, "y": 1, "x": 2}
BUDGET_S = float(sys.argv[1]) if len(sys.argv) > 1 else 160.0


def coarsen(mask, f, thr=0.5):
    if f == 1:
        return mask
    z, y, x = mask.shape
    return mask.reshape(z // f, f, y // f, f, x // f, f).mean((1, 3, 5)) >= thr


def percolating(labels, dim):
    a = np.moveaxis(labels, dim, 0)
    inlet, outlet = np.unique(a[0]), np.unique(a[-1])
    through = np.intersect1d(inlet[inlet > 0], outlet[outlet > 0])
    if not len(through):
        return None
    sizes = np.bincount(labels.ravel())
    return labels == through[np.argmax(sizes[through])]


def diagonal_bridges(m):
    """Count pore-pore contacts across an edge whose two shared face-neighbours are both solid."""
    n = 0
    for a, b in ((0, 1), (0, 2), (1, 2)):
        for sb in (1, -1):
            sl0 = [slice(None)] * 3; sl1 = [slice(None)] * 3; sfa = [slice(None)] * 3; sfb = [slice(None)] * 3
            # voxel p at (i,j), q at (i+1, j+sb) in plane (a,b); face neighbours (i+1,j) and (i,j+sb)
            sl0[a] = slice(0, -1); sl1[a] = slice(1, None); sfa[a] = slice(1, None); sfb[a] = slice(0, -1)
            if sb == 1:
                sl0[b] = slice(0, -1); sl1[b] = slice(1, None); sfa[b] = slice(0, -1); sfb[b] = slice(1, None)
            else:
                sl0[b] = slice(1, None); sl1[b] = slice(0, -1); sfa[b] = slice(1, None); sfb[b] = slice(0, -1)
            n += int(np.sum(m[tuple(sl0)] & m[tuple(sl1)] & ~m[tuple(sfa)] & ~m[tuple(sfb)]))
    return n


def main():
    reg = pd.read_csv(BASE / "roi_registry" / "operator_roi_registry_accepted.csv")
    reg = reg[reg.accepted_for_operator.astype(bool)]
    done = set(pd.read_csv(RAW).roi_id) if RAW.exists() else set()
    todo = reg[~reg.roi_id.isin(done)]
    reader = NetCDFVolumeReader(ROOT / "dataset" / "DRP-236" / "Bentheimer Sandstone", "segmented")
    t0 = time.time(); n = 0
    for _, r in todo.iterrows():
        if time.time() - t0 > BUDGET_S:
            break
        seg, _ = reader.read([int(r.block_index)], [int(r.z_start_local), int(r.z_end_local)],
                             [int(r.y_start), int(r.y_end)], [int(r.x_start), int(r.x_end)])
        pore = np.isin(seg, PORE_LABELS)
        rows = []
        for c, rank in CONN.items():
            st = generate_binary_structure(3, rank)
            lab_native, ncomp = label(pore, structure=st)
            for axis, dim in AXIS_DIM.items():
                stage1 = percolating(lab_native, dim)
                for f in (1, 2, 4):
                    row = {"roi_id": r.roi_id, "split": r.split, "flow_axis": axis, "connectivity": c, "coarsening": f,
                           "native_components": int(ncomp), "native_porosity": float(pore.mean())}
                    if stage1 is None:
                        rows.append({**row, "percolates": False}); continue
                    coarse = coarsen(stage1, f)
                    lab_c, ncc = label(coarse, structure=st)
                    final = percolating(lab_c, dim)
                    if final is None:
                        rows.append({**row, "percolates": False, "stage1_fraction_of_pore": float(stage1.sum() / pore.sum())}); continue
                    rows.append({**row, "percolates": True,
                                 "stage1_fraction_of_pore": float(stage1.sum() / pore.sum()),
                                 "mesh_porosity": float(final.mean()),
                                 "mesh_cells": int(final.sum()),
                                 "coarse_components": int(ncc),
                                 "diagonal_bridges_in_mesh_set": diagonal_bridges(final) if c > 6 else 0})
        pd.DataFrame(rows).to_csv(RAW, mode="a", header=not RAW.exists(), index=False)
        n += 1
    left = len(todo) - n
    print(f"processed {n} ROIs in {time.time() - t0:.0f} s; remaining {left}")


if __name__ == "__main__":
    main()
