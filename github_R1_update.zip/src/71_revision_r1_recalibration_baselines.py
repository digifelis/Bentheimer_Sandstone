"""Reviewer-1 comment 1: is the L1-to-L2 correction more than a recalibration of L1?

All models are fitted on the training blocks only (72 L2 cases, 24 ROIs) and scored on the
36 test-block cases (12 ROIs). Uncertainty: ROI-clustered bootstrap (all three axes of a ROI
are resampled together). Sensitivity: refit on train+validation (108 cases).
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.ensemble import RandomForestRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel, WhiteKernel
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "results" / "operator_v1"
OUT = BASE / "revision_r1" / "recalibration_baselines"
OUT.mkdir(parents=True, exist_ok=True)

L1 = ["log10_l1_k"]
AX = ["axis_x", "axis_y", "axis_z"]
MORPH = ["porosity", "largest_component_fraction_of_pore", "log10_connected_components_6"]
FULL = L1 + MORPH + AX
SEEDS = range(1701, 1711)
N_BOOT = 10000


def rf(seed):
    return RandomForestRegressor(n_estimators=500, min_samples_leaf=2, random_state=seed, n_jobs=-1)


def gp_kernel(d):
    return ConstantKernel(1.0) * RBF(length_scale=np.ones(d), length_scale_bounds=(1e-2, 1e3)) + WhiteKernel(1e-3, (1e-6, 1e0))


class ShiftModel:
    def fit(self, X, y):
        self.c = float(np.mean(y - X[:, 0])); return self
    def predict(self, X):
        return X[:, 0] + self.c


class IsoModel:
    def fit(self, X, y):
        self.m = IsotonicRegression(out_of_bounds="clip").fit(X[:, 0], y); return self
    def predict(self, X):
        return self.m.predict(X[:, 0])


class AR1Model:
    """Kennedy-O'Hagan AR(1) with nested design: y2 = a + rho*y1 + delta(x), delta ~ GP(morphology, axis)."""
    def fit(self, X, y):
        self.lin = LinearRegression().fit(X[:, :1], y)
        r = y - self.lin.predict(X[:, :1])
        self.sc = StandardScaler().fit(X[:, 1:])
        self.gp = GaussianProcessRegressor(gp_kernel(X.shape[1] - 1), normalize_y=True, n_restarts_optimizer=5, random_state=0)
        self.gp.fit(self.sc.transform(X[:, 1:]), r); return self
    def predict(self, X):
        return self.lin.predict(X[:, :1]) + self.gp.predict(self.sc.transform(X[:, 1:]))


class NARGPModel:
    """Nonlinear autoregressive GP (Perdikaris et al. 2017) with observed L1: y2 = g(y1, x)."""
    def fit(self, X, y):
        self.sc = StandardScaler().fit(X)
        self.gp = GaussianProcessRegressor(gp_kernel(X.shape[1]), normalize_y=True, n_restarts_optimizer=5, random_state=0)
        self.gp.fit(self.sc.transform(X), y); return self
    def predict(self, X):
        return self.gp.predict(self.sc.transform(X))


# name -> (feature list, factory(seed), group, stochastic)
MODELS = {
    "uncorrected L1":                   (L1, None, "no correction", False),
    "constant shift (L1 + c)":          (L1, lambda s: ShiftModel(), "recalibration", False),
    "linear calibration (a + b*L1)":    (L1, lambda s: LinearRegression(), "recalibration", False),
    "linear calibration + axis":        (L1 + AX, lambda s: LinearRegression(), "recalibration", False),
    "isotonic calibration":             (L1, lambda s: IsoModel(), "recalibration", False),
    "RF, L1 only":                      (L1, rf, "recalibration", True),
    "RF, L1 + axis":                    (L1 + AX, rf, "recalibration", True),
    "morphology-only RF (no L1)":       (MORPH + AX, rf, "single fidelity", True),
    "ridge, L1 + morphology + axis":    (FULL, lambda s: make_pipeline(StandardScaler(), Ridge(alpha=1.0)), "multi-fidelity", False),
    "AR(1) co-kriging (linear L1 + GP discrepancy)": (FULL, lambda s: AR1Model(), "multi-fidelity", False),
    "NARGP-type GP (L1 + morphology + axis)":       (FULL, lambda s: NARGPModel(), "multi-fidelity", False),
    "RF, L1 + morphology + axis (Table 7)":          (FULL, rf, "multi-fidelity", True),
}
REF = "RF, L1 + morphology + axis (Table 7)"
LIN = "linear calibration (a + b*L1)"


def r2(y, p):
    return 1 - np.sum((y - p) ** 2) / np.sum((y - np.mean(y)) ** 2)


def rmse(y, p):
    return float(np.sqrt(np.mean((y - p) ** 2)))


def fit_predict(train, test, feats, factory, stochastic):
    if factory is None:
        return test["log10_l1_k"].to_numpy()
    Xtr, ytr, Xte = train[feats].to_numpy(float), train["log10_l2_k"].to_numpy(), test[feats].to_numpy(float)
    if not stochastic:
        return factory(0).fit(Xtr, ytr).predict(Xte)
    return np.mean([factory(s).fit(Xtr, ytr).predict(Xte) for s in SEEDS], axis=0)  # seed-averaged


def run(fit_splits, tag):
    t = pd.read_csv(BASE / "multifidelity_correction" / "multifidelity_training_table.csv")
    train, test = t[t.split.isin(fit_splits)], t[t.split == "test"].reset_index(drop=True)
    y = test["log10_l2_k"].to_numpy()
    preds = {n: fit_predict(train, test, f, fac, st) for n, (f, fac, g, st) in MODELS.items()}
    if tag == "train":  # the Table 7 reference is the archived model itself, not a refit
        ap = pd.read_csv(BASE / "multifidelity_correction" / "multifidelity_correction_predictions.csv")
        ap = ap[(ap.model == "random_forest") & (ap.split == "test")]
        preds[REF] = test[["roi_id", "flow_axis"]].merge(ap, on=["roi_id", "flow_axis"], how="left", validate="one_to_one").predicted_log10_l2.to_numpy()
    # seed spread for stochastic models
    spread = {}
    for n, (f, fac, g, st) in MODELS.items():
        if st:
            Xtr, ytr, Xte = train[f].to_numpy(float), train["log10_l2_k"].to_numpy(), test[f].to_numpy(float)
            spread[n] = float(np.std([r2(y, fac(s).fit(Xtr, ytr).predict(Xte)) for s in SEEDS]))
    rois = test.roi_id.to_numpy(); uniq = np.unique(rois); idx = {r: np.where(rois == r)[0] for r in uniq}
    rng = np.random.default_rng(1701)
    boots = [np.concatenate([idx[r] for r in rng.choice(uniq, len(uniq), replace=True)]) for _ in range(N_BOOT)]
    rows = []
    for n, p in preds.items():
        e, eref, elin = np.abs(y - p), np.abs(y - preds[REF]), np.abs(y - preds[LIN])
        b_r2 = np.array([r2(y[b], p[b]) for b in boots])
        b_rm = np.array([rmse(y[b], p[b]) for b in boots])
        b_dref = np.array([rmse(y[b], p[b]) - rmse(y[b], preds[REF][b]) for b in boots])
        b_dlin = np.array([rmse(y[b], p[b]) - rmse(y[b], preds[LIN][b]) for b in boots])
        # ROI-level paired test vs Table-7 RF (12 ROI means of absolute error)
        roi_d = np.array([e[idx[r]].mean() - eref[idx[r]].mean() for r in uniq])
        w = stats.wilcoxon(roi_d) if np.any(roi_d != 0) else None
        rows.append({
            "fit_on": tag, "model": n, "group": MODELS[n][2],
            "test_r2": r2(y, p), "r2_ci_low": np.percentile(b_r2, 2.5), "r2_ci_high": np.percentile(b_r2, 97.5),
            "r2_seed_sd": spread.get(n, np.nan),
            "test_rmse": rmse(y, p), "rmse_ci_low": np.percentile(b_rm, 2.5), "rmse_ci_high": np.percentile(b_rm, 97.5),
            "rmse_minus_tableRF": rmse(y, p) - rmse(y, preds[REF]),
            "rmse_minus_tableRF_ci_low": np.percentile(b_dref, 2.5), "rmse_minus_tableRF_ci_high": np.percentile(b_dref, 97.5),
            "rmse_minus_linear": rmse(y, p) - rmse(y, preds[LIN]),
            "rmse_minus_linear_ci_low": np.percentile(b_dlin, 2.5), "rmse_minus_linear_ci_high": np.percentile(b_dlin, 97.5),
            "rois_worse_than_tableRF": int((roi_d > 0).sum()),
            "wilcoxon_roi_p_vs_tableRF": (w.pvalue if w is not None else np.nan),
        })
    pred_df = test[["roi_id", "flow_axis", "log10_l1_k", "log10_l2_k"]].copy()
    for n, p in preds.items():
        pred_df[n] = p
    pred_df.to_csv(OUT / f"predictions_fit_{tag}.csv", index=False)
    lin = LinearRegression().fit(train[L1], train["log10_l2_k"])
    return pd.DataFrame(rows), {"tag": tag, "intercept": float(lin.intercept_), "slope": float(lin.coef_[0]),
                                "shift_c": float(np.mean(train.log10_l2_k - train.log10_l1_k)), "n_fit": int(len(train))}


def main():
    a, ca = run(["train"], "train")
    b, cb = run(["train", "validation"], "train+validation")
    res = pd.concat([a, b], ignore_index=True)
    res.to_csv(OUT / "recalibration_vs_multifidelity.csv", index=False)
    (OUT / "summary.json").write_text(json.dumps({"linear_calibration": [ca, cb], "n_boot": N_BOOT,
        "bootstrap": "ROI-clustered (12 test ROIs, all axes resampled together)",
        "rf_predictions": "averaged over 10 seeds (1701-1710)"}, indent=2), encoding="utf-8")
    pd.set_option("display.width", 250)
    cols = ["fit_on", "model", "test_r2", "r2_ci_low", "r2_ci_high", "test_rmse", "rmse_minus_tableRF", "rmse_minus_tableRF_ci_low",
            "rmse_minus_tableRF_ci_high", "rmse_minus_linear", "rmse_minus_linear_ci_low", "rmse_minus_linear_ci_high",
            "rois_worse_than_tableRF", "wilcoxon_roi_p_vs_tableRF"]
    print(res[cols].round(4).to_string(index=False)); print(ca, cb)


if __name__ == "__main__":
    main()
