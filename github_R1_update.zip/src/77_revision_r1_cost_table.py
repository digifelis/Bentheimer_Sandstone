"""Reviewer-1 comment 10: one transparent per-case cost table and break-even analysis.

Inputs: archived paired L1/L2 simpleFoam logs (143 explicitly converged pairs), the serial L3
pilot timings, stage timings from src/76 (same CPU), and RF/linear training + inference timed here.
All times are wall-clock seconds for one ROI-axis case on one CPU core unless stated.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "results" / "operator_v1"
SUP = BASE / "revision_support"
OUT = BASE / "revision_r1" / "cost"
FULL = ["log10_l1_k", "porosity", "largest_component_fraction_of_pore", "log10_connected_components_6", "axis_x", "axis_y", "axis_z"]


def q(s):
    return float(np.median(s)), float(np.quantile(s, 0.25)), float(np.quantile(s, 0.75))


def main():
    pairs = pd.read_csv(SUP / "operator_l1_l2_paired_solver_timings_converged.csv")
    st = pd.read_csv(OUT / "stage_timing_raw.csv")
    pilot = pd.read_csv(SUP / "table_completed_cost_accounting.csv")
    prep = {k: q(st[st.stage == k].wall_s) for k in st.stage.unique()}
    t = pd.read_csv(BASE / "multifidelity_correction" / "multifidelity_training_table.csv")
    tr, te = t[t.split == "train"], t[t.split == "test"]
    s = time.perf_counter(); rf = RandomForestRegressor(n_estimators=500, min_samples_leaf=2, random_state=1701, n_jobs=1).fit(tr[FULL], tr.log10_l2_k); rf_fit = time.perf_counter() - s
    one = te[FULL].iloc[[0]]; [rf.predict(one) for _ in range(5)]
    s = time.perf_counter(); [rf.predict(one) for _ in range(200)]; rf_inf = (time.perf_counter() - s) / 200
    s = time.perf_counter(); lin = LinearRegression().fit(tr[["log10_l1_k"]], tr.log10_l2_k); lin_fit = time.perf_counter() - s

    sol = {"L1": q(pairs.clock_time_s_l1), "L2": q(pairs.clock_time_s_l2)}
    sol_cpu = {"L1": q(pairs.execution_time_s_l1), "L2": q(pairs.execution_time_s_l2)}
    rows = [
        ("Case preparation (NetCDF read, percolation, coarsening, mesh/case writing)", "L1/4x", 12, *prep["prepare_L1_4x_cfd"], "this revision, same CPU (VM, 2 vCPU)"),
        ("Case preparation", "L2/2x", 12, *prep["prepare_L2_2x_cfd"], "this revision, same CPU"),
        ("Case preparation", "L3/1x", 3, *prep["prepare_L3_1x_cfd"], "this revision, same CPU"),
        ("Morphology descriptors (read + 6-connected labelling)", "image", 12, *prep["descriptors"], "this revision, same CPU"),
        ("simpleFoam solve, wall clock", "L1/4x", len(pairs), *sol["L1"], "archived logs, 143 converged pairs"),
        ("simpleFoam solve, wall clock", "L2/2x", len(pairs), *sol["L2"], "archived logs, 143 converged pairs"),
        ("simpleFoam solve, CPU time", "L1/4x", len(pairs), *sol_cpu["L1"], "archived logs"),
        ("simpleFoam solve, CPU time", "L2/2x", len(pairs), *sol_cpu["L2"], "archived logs"),
        ("simpleFoam solve, wall clock (serial pilot)", "L3/1x", 5, 831.53, 770.0, 963.0, "archived pilot logs"),
        ("RF correction training (500 trees, 72 cases, 1 core)", "model", 1, rf_fit, rf_fit, rf_fit, "this revision"),
        ("RF correction inference, one case (1 core)", "model", 200, rf_inf, rf_inf, rf_inf, "this revision"),
        ("Linear calibration training", "model", 1, lin_fit, lin_fit, lin_fit, "this revision"),
    ]
    stage = pd.DataFrame(rows, columns=["stage", "tier", "n", "median_s", "q1_s", "q3_s", "source"])
    stage.to_csv(OUT / "table_stage_costs.csv", index=False)

    # per-case operational paths (medians); checkMesh is optional QA and reported separately
    direct_l2 = prep["prepare_L2_2x_cfd"][0] + sol["L2"][0]
    direct_l3 = prep["prepare_L3_1x_cfd"][0] + 831.53
    corr_rf = prep["prepare_L1_4x_cfd"][0] + prep["descriptors"][0] + sol["L1"][0] + rf_inf
    corr_lin = prep["prepare_L1_4x_cfd"][0] + sol["L1"][0]
    # per-pair end-to-end ratio distribution (pair-specific solver times + median preparation)
    r_rf = (prep["prepare_L2_2x_cfd"][0] + pairs.clock_time_s_l2) / (prep["prepare_L1_4x_cfd"][0] + prep["descriptors"][0] + pairs.clock_time_s_l1 + rf_inf)
    r_lin = (prep["prepare_L2_2x_cfd"][0] + pairs.clock_time_s_l2) / (prep["prepare_L1_4x_cfd"][0] + pairs.clock_time_s_l1)
    paths = pd.DataFrame([
        {"path": "direct L2 CFD", "per_case_s": direct_l2, "result": "L2 response (reference)"},
        {"path": "L1 CFD + linear calibration", "per_case_s": corr_lin, "result": "L2 estimate, test RMSE 0.067 log10"},
        {"path": "L1 CFD + descriptors + RF correction", "per_case_s": corr_rf, "result": "L2 estimate, test RMSE 0.060 log10"},
        {"path": "direct L3 CFD (for scale)", "per_case_s": direct_l3, "result": "native voxel response"},
    ])
    paths["speedup_vs_direct_L2"] = direct_l2 / paths.per_case_s
    paths.to_csv(OUT / "table_operational_paths.csv", index=False)

    # break-even: number of new cases N after which training cost is recovered
    # training overhead = L2 runs needed to fit the correction (+ their L1 runs) + model fit
    be = []
    for name, n_l2, per_corr, fit in (("RF correction, 72 L2 training cases (as in paper)", 72, corr_rf, rf_fit),
                                      ("linear calibration, 72 L2 training cases", 72, corr_lin, lin_fit),
                                      ("linear calibration, 18 L2 training cases (6 ROIs; learning curve plateau)", 18, corr_lin, lin_fit)):
        overhead = n_l2 * (direct_l2 + corr_lin) + fit
        saving = direct_l2 - per_corr
        be.append({"workflow": name, "training_overhead_s": overhead, "saving_per_new_case_s": saving,
                   "break_even_new_cases": float(np.ceil(overhead / saving)),
                   "net_saving_for_1000_cases_h": (1000 * saving - overhead) / 3600})
    be = pd.DataFrame(be); be.to_csv(OUT / "table_break_even.csv", index=False)
    rep = {"pilot_checkMesh_median_s": {"L2": 4.94, "L3": 25.46, "L1": "not separately timed"},
           "pair_end_to_end_ratio_rf": q(r_rf), "pair_end_to_end_ratio_linear": q(r_lin),
           "pair_solver_only_ratio": q(pairs.clock_time_s_l2 / pairs.clock_time_s_l1)}
    (OUT / "cost_summary.json").write_text(json.dumps(rep, indent=2), encoding="utf-8")
    pd.set_option("display.width", 250); pd.set_option("display.max_colwidth", 70)
    print(stage.round(4).to_string(index=False)); print(paths.round(2).to_string(index=False)); print(be.round(2).to_string(index=False)); print(json.dumps(rep, indent=1))


if __name__ == "__main__":
    main()
