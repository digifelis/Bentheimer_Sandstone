# Corrections after the internal audit (2026-11-12)

The CSV/JSON outputs and the manuscript/supplement are authoritative. The PHASE*_REPORT.md files were written earlier; where they differ, these values supersede them.

- ROI-level statistics for the principal RF result now use the archived Table 7 model itself (not a 10-seed average) and one shared set of 10,000 ROI bootstrap draws:
  R² 0.867 [0.64, 0.96]; RMSE reduction 33.8% [ROI CI 3.4, 60.3]; 9/12 ROIs improved; Wilcoxon one-sided p = 0.008; exact sign-flip p = 0.008.
- Linear calibration vs Table 7 RF: ΔRMSE 0.007 [−0.001, 0.012], Wilcoxon p = 0.20. Linear calibration test R² = 0.836 (not 0.837).
- RF-corrected L1 vs L3: median ratio 1.30, mean abs. deviation 33.2%, RMSE 0.141 [0.112, 0.170], Spearman 0.89.
- L3 level bias: the connected-porosity shift (+4.0% at L2, −3.6% at L1) is consistent with L2 > L1 but does not explain why both tiers exceed L3; case-level correlation between permeability offset and porosity offset is absent (ρ = 0.11 and −0.11, p > 0.5). The cause is not isolated.
- AR(1) co-kriging and NARGP are simplified implementations (two-stage fit; single GP with ARD squared-exponential kernel). GP fits raise only "length scale at upper bound" notices (irrelevant inputs).
- Independent verification: `src/79_revision_r1_verification.py` → `verification_checks.csv`.
