# Reviewer 1, comment 1 – recalibration vs multi-fidelity baselines

Script: `src/71_revision_r1_recalibration_baselines.py`. Fit on training blocks (72 cases / 24 ROIs); test = 36 cases / 12 ROIs.
95% CIs: ROI-clustered bootstrap (5000 resamples; the three axes of a ROI are resampled together). RF predictions averaged over 10 seeds.
ROI-level test: Wilcoxon signed-rank on the 12 per-ROI mean absolute errors vs the Table 7 RF.

| Model (fit on train) | Test R² [95% CI] | RMSE | ΔRMSE vs Table 7 RF [95% CI] | Wilcoxon p (ROI) |
|---|---|---|---|---|
| Uncorrected L1 | 0.696 [0.35, 0.83] | 0.091 | +0.031 [+0.003, +0.062] | 0.012 |
| Constant shift (L1 + c) | 0.791 | 0.076 | +0.015 [+0.000, +0.034] | 0.73 |
| **Linear calibration a + b·L1 (2 parameters)** | **0.836 [0.56, 0.95]** | 0.067 | +0.007 [−0.000, +0.012] | 0.23 |
| Linear calibration + axis | 0.844 | 0.066 | +0.005 [−0.001, +0.009] | 0.62 |
| Isotonic calibration | 0.832 | 0.068 | +0.008 [+0.003, +0.012] | 0.08 |
| RF, L1 only | 0.803 | 0.074 | +0.013 | 0.005 |
| Morphology-only RF (no L1) | 0.546 | 0.112 | +0.051 | 0.003 |
| Ridge, L1 + morphology + axis | 0.841 | 0.066 | +0.006 [−0.002, +0.016] | 0.73 |
| AR(1) co-kriging (Kennedy–O'Hagan) | 0.840 | 0.066 | +0.006 [−0.001, +0.013] | 0.62 |
| NARGP-type GP | 0.854 | 0.063 | +0.003 [−0.003, +0.011] | 0.73 |
| RF, L1 + morphology + axis (Table 7) | 0.867 [0.64, 0.96] | 0.060 | – | – |

Sensitivity, fit on train+validation (108 cases): linear 0.814, AR(1) co-kriging 0.833, NARGP 0.838, Table 7 RF 0.817, ridge 0.804.

Linear calibration fitted on train: log10 k_L2 = −2.18 + 0.806·log10 k_L1 (slope < 1: the finer tier raises permeability relatively more for low-permeability ROIs).

## Conclusions
1. Every correction beats uncorrected L1; the RF gain over L1 is significant at ROI level (ΔRMSE CI excludes 0; p = 0.012).
2. A two-parameter linear calibration of L1 reaches R² = 0.836; the RF advantage over it (ΔRMSE 0.007, CI −0.000 to 0.012, p = 0.23) is not statistically resolved with 12 test ROIs.
3. Formal multi-fidelity models (AR(1) co-kriging, NARGP) perform at the level of linear calibration.
4. The RF advantage is not robust to the training set: with 108 cases RF falls to 0.817, below AR(1) co-kriging.
5. With 12 test ROIs, R² CIs are wide (~0.3 units); single-split point estimates should not be ranked.
