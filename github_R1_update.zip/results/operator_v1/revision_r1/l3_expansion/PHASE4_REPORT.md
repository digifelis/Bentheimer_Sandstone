# Reviewer 1 – comments 5 and 13: 36-case native-resolution (L3) comparison

Scripts: `scripts/run_l3_expansion_wsl.sh` (runs), `src/75_revision_r1_l3_expansion_analysis.py` (comparison), `src/78_revision_r1_l3_mechanism.py` (mechanism).
Design fixed before any new result: all 12 L2 test ROIs × 3 axes = 36 cases (2 from the pilot). All 36 converged and were accepted (max imbalance 0.00007%).

| Tier vs L3 | Median ratio | Mean abs. dev. (%) | RMSE log10 [ROI 95% CI] | Spearman | R² (log) | LORO offset RMSE |
|---|---|---|---|---|---|---|
| L1/4x | 1.13 | 23.1 | 0.113 [0.076–0.145] | 0.88 | 0.75 | 0.097 |
| L2/2x | 1.26 | 30.7 | 0.124 [0.104–0.146] | 0.97 | 0.92 | 0.051 |
| L1 + linear calibration | 1.23 | 34.2 | 0.147 [0.113–0.181] | 0.88 | 0.75 | 0.091 |
| L1 + RF correction | 1.30 | 33.0 | 0.140 [0.111–0.169] | 0.90 | 0.81 | 0.080 |

- L2 closer to L3 than L1 in 6/36 cases. Level orderings: L3<L1<L2 24, L1<L3<L2 8, L3<L2<L1 4.
- Connected (mesh) porosity vs L3: L2 higher in 36/36 (median +4.0%), L1 lower in 36/36 (median −3.6%). This is consistent with the inclusive 0.5 block-average threshold.
- Interpretation: non-monotonic in level, ordered in rank information (L1 < corrected L1 < L2). L2 is a rank-faithful but upward-biased (~1.26×) proxy of the native voxel response.
