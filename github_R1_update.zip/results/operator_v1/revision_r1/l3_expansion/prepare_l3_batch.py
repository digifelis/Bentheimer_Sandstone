"""Prepare L3 expansion cases one at a time within a time budget (resumable)."""
import sys, time
from pathlib import Path
import pandas as pd
ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / "src"))
from bentheimer.data import NetCDFVolumeReader
from bentheimer.operator_cases import prepare_operator_case
budget = float(sys.argv[1]) if len(sys.argv) > 1 else 100
plan = pd.read_csv(Path(__file__).with_name("l3_expansion_plan.csv"))
out = ROOT / "results" / "operator_v1" / "openfoam_cases"
reader = NetCDFVolumeReader(ROOT / "dataset" / "DRP-236" / "Bentheimer Sandstone", "segmented", (4.95, 4.95, 4.95))
t0 = time.time(); last = 65.0
for task in plan.to_dict(orient="records"):
    case = out / "L3_1x_cfd" / task["split"] / f"{task['roi_id']}_{task['flow_axis']}"
    if (case / "operator_task_manifest.json").exists():
        continue
    if time.time() - t0 + last * 1.15 > budget:
        break
    s = time.time()
    prepare_operator_case(pd.Series(task), reader, out, pore_fraction_threshold=0.5, overwrite=True)
    last = time.time() - s
    print(f"prepared {case.name} in {last:.0f} s", flush=True)
left = sum(not (out / "L3_1x_cfd" / t["split"] / f"{t['roi_id']}_{t['flow_axis']}" / "operator_task_manifest.json").exists() for t in plan.to_dict(orient="records"))
print("remaining", left)
