# Reviewer 1 revision – Phase 1 audit report

Script: `src/70_revision_r1_phase1_audit.py` (scikit-learn 1.7.2; archive produced with 1.9.0)

## 1. Table 7 reproduction
Archived RF correction test R² = 0.8667 / RMSE = 0.0604; reproduced R² = 0.8666 / RMSE = 0.0605. Uncorrected L1 R² = 0.6957. **Table 7 is unchanged.**
Training: 72 cases from 24 ROIs; test: 36 cases from 12 ROIs.

## 2. Table 9 model mismatch (corrected)
The archived Table 9 came from `scripts/operator_v1_fractal_xai.py`: 600 trees, seed 1729, trained on train+validation (108 cases), 9 features including box-counting dimension and lacunarity. Its test R² is 0.825, not 0.867. Table 9 therefore described a different model from Table 7.

Corrected Table 9 (same model as Table 7, permutation on the 36 test cases, 100 repeats):

| Feature | Gini | Permutation R² drop | SD |
|---|---|---|---|
| log10_l1_k | 0.930 | 1.567 | 0.308 |
| porosity | 0.047 | 0.029 | 0.011 |
| axis_y | 0.004 | 0.015 | 0.007 |
| largest_component_fraction_of_pore | 0.009 | 0.009 | 0.005 |
| log10_connected_components_6 | 0.007 | 0.000 | 0.001 |
| axis_z / axis_x | ≤0.001 | ≈0 | – |

Grouped refit (10 seeds, test R²): full 0.867 ± 0.001; without L1 0.546; without morphology 0.828; without flow axis 0.862.
Adding box-counting dimension + lacunarity under the same protocol: 0.8667 vs 0.8669 without (no added value).

## 3. RF hyperparameters (Reviewer comment 2)
n_estimators 500; min_samples_leaf 2; min_samples_split 2; max_depth None (realised mean depth 6.8, ~20 leaves per tree); max_features 1.0 (all 7 features); bootstrap True; random_state 1701. Not tuned; fixed a priori; validation block not used; not retrained on train+validation. Ridge: alpha 1.0 with standardisation, also fixed.

## 4. L2 subset selection (comment 4)
Within each split, accepted ROIs were sorted by image porosity and n = 24/12/12 ROIs taken at evenly spaced rank positions; all three axes simulated. Reconstruction from the registry matches the archive exactly. No permeability information was used. Porosity KS test, selected vs pool: D = 0.031/0.061/0.061, p = 1.0 in all splits; the selected subsets cover the full porosity range of each split.

## 5. Block geometry (comments 3 and 12)
Blocks 0–3 are contiguous 360-slice z-segments (z = 0–360–720–1080–1440) of one DRP-236 specimen. Train (blocks 0–1) and test (block 3) are separated by the whole validation block: minimum separation 360 voxels (1.78 mm). Validation touches both train and test. In the L2 subset, 2 of 12 test ROIs and 7 of 12 validation ROIs touch a neighbouring split's face. The RF/ridge corrections do not use the validation block, so the relevant train–test separation is ≥360 voxels.

## Proposed manuscript text (to be applied in Phase 6 with tracked changes)
- Section 3.3, Table 9 paragraph: "Permutation importance computed for the same random-forest correction reported in Table 7 showed that log10 L1 permeability dominated (R² drop 1.567 ± 0.308), followed by porosity (0.029 ± 0.011); connectivity and flow-axis terms were ≤0.015. Removing L1 permeability reduced test R² to 0.546, removing the three morphology descriptors reduced it to 0.828, and adding interface box-counting dimension and lacunarity did not change it (0.867)."
- Delete: "Porosity and lacunarity contributed smaller positive terms …" and "total scale-sensitive descriptor share … 1.86%".
- Section 2.4: add RF/ridge hyperparameter and protocol sentence (Section 3 above).
- Section 2.2/2.5: add L2 selection algorithm (Section 4) and block-geometry description (Section 5); replace "independent blocks" with "spatially disjoint, contiguous sub-volumes of a single DRP-236 specimen".
