# Reviewer 1 – comment 6 (connectivity) and comment 4 (L2 selection)

Scripts: `src/73_revision_r1_connectivity_sensitivity.py` (per ROI and axis, resumable) and `src/74_revision_r1_connectivity_summary.py`.
Pipeline re-implemented as in `bentheimer.voxel_mesh.build_voxel_mesh`: native pore mask (labels 0, 2) → percolating component → block-average coarsening (threshold 0.5) → percolating component. The connectivity criterion is applied at both stages.
Reproduction check (6-connectivity): 144/144 L1 and 144/144 L2 archived mesh cell counts reproduced exactly.

## Comment 6 – 6 vs 18 vs 26 connectivity (180 ROIs × 3 axes = 540 cases per tier)

| Tier | Connectivity | Percolating | Mesh porosity | Δ pore volume vs 6-conn., median / 95th pct / max (%) | Edge/corner-only contacts per 1000 cells (median) |
|---|---|---|---|---|---|
| L3/1x | 6 | 540/540 | 0.2279 | – | – |
| L3/1x | 26 | 540/540 | 0.2280 | 0.01 / 0.07 / 0.40 | 0.34 |
| L2/2x | 6 | 540/540 | 0.2369 | – | – |
| L2/2x | 26 | 540/540 | 0.2374 | 0.11 / 0.54 / 2.26 | 4.5 |
| L1/4x | 6 | 540/540 | 0.2197 | – | – |
| L1/4x | 26 | 540/540 | 0.2234 | 1.52 / 3.43 / 12.07 | 31.8 |

18-connectivity results lie between 6 and 26 (L1 median +1.28%).

- Every case percolates under all three criteria. The choice never changes whether a ROI conducts.
- At native and L2 resolution the choice is practically irrelevant (≤0.11% median pore volume).
- At L1, coarsening turns narrow throats into edge/corner-only contacts: ~100× more than native (31.8 vs 0.34 per 1000 cells). This adds 1.5% of pore volume at the median and up to 12% under 26-connectivity.
- Physical rationale for 6-connectivity: the OpenFOAM mesh is face-based, so voxels joined only through an edge or corner share zero face area and cannot exchange flux. Including them (18/26) would add disconnected or non-manifold regions with no hydraulic function. 6-connectivity is therefore the only criterion consistent with the solver geometry. The edge/corner contacts are a representation of sub-voxel throats that the coarse tier cannot resolve.
- Link to resolution bias: across the 144 matched cases, the 26-vs-6 pore-volume gain at L1 correlates with the L2/L1 permeability ratio (Spearman ρ = 0.31, p = 0.0002). The L2/L1 mesh-porosity ratio shows ρ = 0.29 (p = 0.0003). ROIs whose L1 representation loses more face-connected throats are those L1 underpredicts most. This supports the throat-disconnection interpretation of the resolution bias (associative, not causal).

## Comment 4 – L2 subset selection, outcome-blind check
Porosity-rank stratified selection (see Phase 1). L1 log-permeability of selected vs unselected ROIs:
- Test: KS p = 0.64; validation: KS p = 0.81.
- Train: KS p = 0.023. The selected training ROIs have a slightly higher median L1 log-k (−11.48 vs −11.56, ~0.07 log10 units).
- In every split the selected subset spans the full L1 permeability range of the pool.

The test subset is representative; the mild training shift should be reported.
