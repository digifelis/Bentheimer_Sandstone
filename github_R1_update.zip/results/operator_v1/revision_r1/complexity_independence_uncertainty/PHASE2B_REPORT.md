# Reviewer 1 – comments 2, 3 and 9

Script: `src/72_revision_r1_complexity_independence_uncertainty.py` (run as `c2`, `c3`, `c9`). Fit on training blocks (72 cases / 24 ROIs) unless stated; test = 36 cases / 12 ROIs.

## Comment 2 – RF complexity and small L2 set
- Fixed configuration (500 trees, min_samples_leaf 2, no depth limit, max_features 1.0): test R² 0.867; OOB R² 0.862.
- 60-configuration grid (leaf 1–8 × depth None/3/5/8 × max_features 1.0/0.6/0.33): test R² 0.64–0.87, median 0.82. The low end is leaf 8 with max_features 0.33 (splits often cannot use L1).
- Selection by ROI-grouped 6-fold CV on the training blocks only → leaf 2, depth 5, max_features 1.0 → test R² 0.864 (equivalent to the fixed model).
- Selection by the validation block → leaf 2, depth 3, max_features 0.6 → test R² 0.819.
- n_estimators 100/300/500/1000: test R² 0.867/0.868/0.867/0.867.
- Learning curve (20 random ROI subsets per size):

| Training ROIs (cases) | RF test R² | Linear calibration test R² |
|---|---|---|
| 6 (18) | 0.61 ± 0.20 | 0.83 ± 0.01 |
| 12 (36) | 0.80 ± 0.05 | 0.83 ± 0.01 |
| 18 (54) | 0.85 ± 0.02 | 0.84 ± 0.00 |
| 24 (72) | 0.87 | 0.84 |

The RF only matches the two-parameter calibration at ~18 training ROIs; the calibration is saturated at 6 ROIs.

## Comment 3 – independence
- Axis intraclass correlation within ROI: log10 k_L2 0.70, log10 k_L1 0.66, L2–L1 bias 0.26. Design effect 2.4 → the 36 test cases carry ~15 effective independent observations; inference must be at ROI level (12 ROIs).
- Train (blocks 0–1) and test (block 3) are separated by ≥360 voxels (1.78 mm); the corrections never use the validation block.
- Semivariogram over all 180 ROIs: porosity and ROI-mean L1 log-k reach 0.79–0.89 of the sill at the shortest lag (mean 0.74 mm) and the sill at ~1.1 mm. The spatial correlation range is shorter than the train–test separation (shorter lags cannot be resolved with non-overlapping 160³ ROIs).
- Buffer exclusion of the 2 test ROIs touching the validation block: RF 0.861, linear 0.828, uncorrected 0.730 (vs 0.867/0.836/0.696). Ranking unchanged. A 160-voxel buffer leaves only 5 ROIs (RF 0.714, linear 0.669, uncorrected 0.661).
- RF residuals across the 12 test ROIs: Moran's I −0.28 (expected −0.09, permutation p = 0.047), so there is no positive spatial autocorrelation.

## Comment 9 – uncertainty of the principal RF result
- Point estimate (10-seed average): R² 0.867, RMSE 0.060, RMSE reduction vs uncorrected L1 33.9%.
- 95% CI, case bootstrap (as in the manuscript): R² 0.73–0.94; RMSE reduction 11.2–54.4%.
- 95% CI, ROI-clustered bootstrap (recommended): R² 0.65–0.96; RMSE reduction 4.3–60.0%.
- ROI-level paired tests: 9 of 12 ROIs improved; Wilcoxon one-sided p = 0.006; exact ROI sign-flip permutation p = 0.007.
- Split-conformal prediction intervals (RF trained on train, calibrated on the 36 validation cases): 90% interval ±0.147 log10 (factor 1.40), empirical test coverage 94%; 80% interval ±0.088 log10 (factor 1.22), coverage 92%.
