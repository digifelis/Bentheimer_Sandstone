# Reviewer 1 – comment 10: transparent cost accounting

Scripts: `src/76_revision_r1_stage_timing.py` (stage timing) and `src/77_revision_r1_cost_table.py` (tables, break-even).
All stages are timed on the same CPU (Intel i7-12650H). Solver times come from the archived serial logs; preparation, descriptor and model times were timed in this revision.

## Stage costs (one ROI-axis case, wall clock, median [IQR])
| Stage | L1/4x | L2/2x | L3/1x |
|---|---|---|---|
| Case preparation (read, percolation, coarsening, case writing) | 1.24 s [1.00–1.75], n=12 | 2.73 s [2.67–2.90], n=12 | 15.9 s, n=3 |
| simpleFoam (archived) | 2.0 s [2–3] (CPU 1.43 s), n=143 | 31.0 s [23–41.5] (CPU 26.3 s), n=143 | 831.5 s, n=5 serial pilot |
| checkMesh (optional QA) | not timed | 4.94 s (pilot) | 25.5 s (pilot) |

Morphology descriptors: 1.08 s. RF training (72 cases, 500 trees, 1 core): 0.24 s. RF inference (1 case, 1 core): 11 ms. Linear calibration: <3 ms.

## Operational per-case paths (medians, checkMesh excluded)
| Path | s per case | Speed-up vs direct L2 | Output |
|---|---|---|---|
| Direct L2 CFD | 33.7 | 1.0× | L2 response |
| L1 CFD + linear calibration | 3.2 | 10.4× (pairwise median 9.2×, IQR 7.6–11.2) | L2 estimate, RMSE 0.067 log10 |
| L1 CFD + descriptors + RF | 4.3 | 7.8× (pairwise median 6.9×, IQR 5.7–9.0) | L2 estimate, RMSE 0.060 log10 |
| Direct L3 CFD (scale only) | 847 | – | native voxel response |

The previously reported 12.5× is the solver-only ratio. Including preparation and descriptors, the realistic end-to-end factor for the RF path is ~7×.
The archived host-side L2 preparation benchmark (5.4 s, writing to the Windows-mounted project folder) is slower than the 2.7 s measured here (local disk). The preparation numbers are therefore lower bounds, and the end-to-end factor plausibly lies at ~6.5–8×.

## Break-even (training overhead = L2 + L1 runs of the training cases + model fit)
| Workflow | Overhead | Saving per new case | Break-even | Net saving per 1000 new cases |
|---|---|---|---|---|
| RF, 72 L2 training cases (paper) | 44 min | 29.4 s | 91 cases | 7.4 h |
| Linear, 72 L2 training cases | 44 min | 30.5 s | 88 cases | 7.7 h |
| Linear, 18 L2 training cases (6 ROIs) | 11 min | 30.5 s | 22 cases | 8.3 h |

## Interpretation for the manuscript
- The corrected workflow is ~7–10× cheaper per case than direct L2, after ~90 new cases (RF, as trained here).
- Absolute savings are modest because an L2 solve costs only ~30 s. The practical value is for large ROI libraries or screening.
- A correction to the native L3 tier (~850 s per case) would have larger value but is not demonstrated (see L3 expansion, comment 5).
- Latency ratios such as 10,465× (L2 solver / RF inference) should be removed from the main text: they omit the required L1 solve.
