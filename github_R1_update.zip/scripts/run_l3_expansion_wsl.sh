#!/usr/bin/env bash
# Reviewer-1 comment 5: native L3/1x CFD for the 12 L2 test-block ROIs x 3 flow axes (36 cases).
# Resumable: already prepared cases are not re-prepared; cases whose log.simpleFoam ends with "End" are skipped.
# Usage (inside WSL):  bash scripts/run_l3_expansion_wsl.sh [JOBS]
#   JOBS = number of simultaneous simpleFoam runs (default 2; each needs ~1.6 GB RAM and ~300 MB disk).
set -uo pipefail

PROJECT_ROOT="${PROJECT_ROOT:-/path/to/project}"
WIN_PY="${WIN_PY:-/path/to/windows/python.exe}"
JOBS="${1:-2}"
EXP="$PROJECT_ROOT/results/operator_v1/revision_r1/l3_expansion"
PLAN="$EXP/l3_expansion_plan.csv"
CASE_ROOT="$PROJECT_ROOT/results/operator_v1/openfoam_cases/L3_1x_cfd/test"
export WM_PROJECT_DIR="${WM_PROJECT_DIR:-/usr/share/openfoam}"
export FOAM_ETC="${FOAM_ETC:-/usr/share/openfoam/etc}"

command -v simpleFoam >/dev/null 2>&1 || { echo "simpleFoam not found: source OpenFOAM first." >&2; exit 1; }
[ -f "$PLAN" ] || { echo "Plan not found: $PLAN" >&2; exit 1; }

# ---------------------------------------------------------------- 1. case preparation
echo "[1/3] Preparing missing cases ..."
if [ -x "$WIN_PY" ]; then
  "$WIN_PY" "$(wslpath -w "$EXP/prepare_l3_batch.py")" 1000000 || { echo "Preparation failed." >&2; exit 1; }
elif python3 -c "import xarray, netCDF4, scipy, pandas" >/dev/null 2>&1; then
  python3 "$EXP/prepare_l3_batch.py" 1000000 || { echo "Preparation failed." >&2; exit 1; }
else
  echo "No Python with xarray/netCDF4 found. Set WIN_PY to your conda python.exe." >&2; exit 1
fi

# ---------------------------------------------------------------- 2. case list and disk check
mapfile -t CASES < <(awk -F, 'NR==1{for(i=1;i<=NF;i++){if($i=="roi_id")a=i;if($i=="flow_axis")b=i}} NR>1{print $a"_"$b}' "$PLAN")
TODO=()
for c in "${CASES[@]}"; do
  d="$CASE_ROOT/$c"
  if [ -f "$d/log.simpleFoam" ] && tail -n 5 "$d/log.simpleFoam" | grep -q "^End"; then continue; fi
  TODO+=("$d")
done
echo "[2/3] Cases in plan: ${#CASES[@]}; still to solve: ${#TODO[@]}; parallel jobs: $JOBS"
FREE_MB=$(df -Pm "$CASE_ROOT" | awk 'NR==2{print $4}')
NEED_MB=$(( ${#TODO[@]} * 200 + 2000 ))
echo "      free disk: ${FREE_MB} MB; estimated need: ${NEED_MB} MB"
if [ "$FREE_MB" -lt "$NEED_MB" ]; then echo "Not enough free disk space. Free space or run fewer cases." >&2; exit 1; fi

# ---------------------------------------------------------------- 3. solve
run_case() {
  local d="$1"
  cd "$d" || return 1
  local t0=$(date +%s)
  /usr/bin/time -v -o log.checkmesh_resource checkMesh -allTopology -allGeometry > log.checkMesh 2>&1
  /usr/bin/time -v -o log.resource_usage simpleFoam > log.simpleFoam 2>&1
  local status="FAILED"
  tail -n 5 log.simpleFoam | grep -q "^End" && status="ok"
  grep -q "SIMPLE solution converged" log.simpleFoam && status="$status,converged"
  echo "$(date '+%F %T') $(basename "$d") $status $(( $(date +%s) - t0 )) s" | tee -a "$EXP/run_log.txt"
}
export -f run_case
export EXP
echo "[3/3] Solving ... (progress also written to $EXP/run_log.txt)"
printf '%s\n' "${TODO[@]}" | xargs -P "$JOBS" -I{} bash -c 'run_case "$@"' _ {}
echo "Finished. Unfinished cases (if any) are picked up by re-running this script."
